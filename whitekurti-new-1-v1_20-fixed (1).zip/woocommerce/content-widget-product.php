<?php
/**
 * WhiteKurti — content-widget-product.php
 *
 * WhiteKurti override of WooCommerce's default
 * woocommerce/content-widget-product.php.
 *
 * FIX v1.6: WooCommerce's classic Product widgets (Recently Viewed
 * Products, On Sale Products, Featured Products, Best Selling
 * Products, Top Rated Products, etc.) all render through this one
 * template. The theme had never overridden it, and this theme
 * intentionally dequeues WooCommerce's own default stylesheet
 * elsewhere — so any place these widgets were used (for example, a
 * "New In Store" widget shown on the empty cart page) fell back to
 * completely unstyled markup: a plain text "Sale!" flash instead of
 * the shop's "−13%" badge, default anchor/button colours instead of
 * this theme's button design, and no card layout at all.
 *
 * This override reuses wk_product_card() — the exact same function
 * that renders every product card on the shop grid (see
 * content-product.php) — so products shown via any of these widgets
 * now look and behave identically to the rest of the site. The
 * matching grid layout for the `<ul>` these `<li>` items sit inside
 * lives in assets/css/wk-fixes.css.
 *
 * This can be overridden by copying it to yourtheme/woocommerce/content-widget-product.php.
 *
 * @package WooCommerce\Templates
 */

defined( 'ABSPATH' ) || exit;

// WooCommerce's widget classes pass the product either as $args['product']
// or as the already-global $product, depending on version/widget — cover
// both so this works everywhere the core template would have.
$wk_widget_product = isset( $args ) && isset( $args['product'] ) ? $args['product'] : ( isset( $product ) ? $product : null );

if ( ! $wk_widget_product instanceof WC_Product ) {
	return;
}
if ( ! $wk_widget_product->is_visible() ) {
	return;
}
?>
<li class="wk-widget-product-item">
	<?php wk_product_card( $wk_widget_product, [ 'layout' => 'editorial' ] ); ?>
</li>
