<?php
/**
 * Proceed to Checkout button
 *
 * WhiteKurti override of WooCommerce's default
 * cart/proceed-to-checkout-button.php.
 *
 * FIX v1.5.1: two earlier attempts to fix this button's unreadable
 * dark-on-dark colours purely through enqueued CSS (once in main.css,
 * then again with maximum-specificity rules in wk-fixes.css) did not
 * survive on the live site. That points to something outside the theme's
 * own stylesheets — a caching / CSS-optimisation plugin, a CDN-level
 * minifier, or similar — silently re-ordering, combining, or stripping
 * rules before they reach the browser.
 *
 * An inline style="" attribute on the element itself always wins over
 * anything coming from an external stylesheet, cached or not, so this
 * override styles the button directly in its own markup instead of
 * relying on a CSS file at all. The background/border still follow the
 * same Customizer tokens (Appearance → Customize → Colour Tokens) the
 * rest of the site uses, so it stays in sync if those are ever changed.
 *
 * FIX v1.6: the label was previously set to the accent colour, which on
 * a dark/black button background (as configured on the live site) reads
 * as low-contrast, hard-to-read text. The label is now always white so
 * it stays legible regardless of what the background colour is set to.
 *
 * This can be overridden by copying it to yourtheme/woocommerce/cart/proceed-to-checkout-button.php.
 *
 * @package WooCommerce\Templates
 */

defined( 'ABSPATH' ) || exit;

$wk_bg     = sanitize_hex_color( get_theme_mod( 'wk_color_bg', '#FDFCFA' ) ) ?: '#FDFCFA';
$wk_accent = sanitize_hex_color( get_theme_mod( 'wk_color_accent', '#6B1E3E' ) ) ?: '#6B1E3E';
$wk_text   = '#ffffff';

$wk_style_rest = sprintf(
	'display:flex!important;align-items:center!important;justify-content:center!important;width:100%%!important;' .
	'background:%1$s!important;color:%3$s!important;font-size:12px!important;font-weight:600!important;' .
	'letter-spacing:.1em!important;text-transform:uppercase!important;text-decoration:none!important;' .
	'padding:14px 24px!important;border:1.5px solid %2$s!important;border-radius:0!important;' .
	'box-shadow:none!important;box-sizing:border-box!important;transition:background .2s,color .2s;',
	esc_attr( $wk_bg ),
	esc_attr( $wk_accent ),
	esc_attr( $wk_text )
);
?>
<a href="<?php echo esc_url( wc_get_checkout_url() ); ?>"
	class="checkout-button button alt wc-forward"
	style="<?php echo esc_attr( $wk_style_rest ); ?>"
	onmouseover="this.style.setProperty('background','<?php echo esc_js( $wk_accent ); ?>','important');this.style.setProperty('color','<?php echo esc_js( $wk_text ); ?>','important');"
	onmouseout="this.style.setProperty('background','<?php echo esc_js( $wk_bg ); ?>','important');this.style.setProperty('color','<?php echo esc_js( $wk_text ); ?>','important');"
	onfocus="this.style.setProperty('background','<?php echo esc_js( $wk_accent ); ?>','important');this.style.setProperty('color','<?php echo esc_js( $wk_text ); ?>','important');"
	onblur="this.style.setProperty('background','<?php echo esc_js( $wk_bg ); ?>','important');this.style.setProperty('color','<?php echo esc_js( $wk_text ); ?>','important');">
	<?php esc_html_e( 'Proceed to checkout', 'woocommerce' ); ?>
</a>
