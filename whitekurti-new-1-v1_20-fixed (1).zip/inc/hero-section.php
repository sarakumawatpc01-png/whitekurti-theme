<?php
/**
 * WhiteKurti — Hero Section (v24: image + text overlay)
 * FIX v24: replaced the old "RANG v3" hero (animated gradients, SVG
 * mandala/paisley/jali ornaments, canvas particle system, mouse parallax,
 * gyroscope tilt) with a straightforward image-with-text-overlay carousel.
 * Each slide = a real photo (uploaded via Customizer) with a dark gradient
 * for legibility and eyebrow/heading/subhead/CTA text on top. Simple
 * autoplay + arrows + dots + swipe, no decorative JS overhead.
 *
 * NOTE: uses the "wk-herobanner" class namespace (NOT "wk-hero__*") on
 * purpose — template-about.php already reuses .wk-hero / .wk-hero__content /
 * .wk-hero__sub / .wk-hero__bg-img / .wk-hero__overlay for its own simple
 * page hero, and that page's CSS was already getting silently overridden by
 * the old homepage hero's same-named rules (both were unscoped, so whichever
 * was later in main.css always won — a v17-v23 bug). Keeping this section on
 * its own class names avoids re-creating that collision.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Single source of truth for hero slide defaults (text + fallback image).
 * FIX v26: previously inc/customizer.php registered rich defaults for the
 * Customizer UI, but wk_render_interactive_hero() below called get_theme_mod()
 * with '' as the fallback instead of reusing those same defaults. On a fresh
 * install — before an admin ever opens the Customizer and clicks Save —
 * WordPress has no rows in the theme_mods option at all, so every
 * get_theme_mod(..., '') call returned '', every slide looked empty, and the
 * whole hero section silently disappeared. Both the Customizer and the
 * renderer now read from this one function so they can never drift apart.
 */
function wk_hero_defaults() {
	$img_base = defined( 'WK_URI' ) ? WK_URI . '/assets/images/hero-banner.png' : '';
	return [
		1 => [ 'image' => $img_base, 'eyebrow' => 'New Collection',      'heading' => "Elegance in\nEvery Thread",     'sub' => 'Handcrafted kurtis for the modern Indian woman',         'cta' => 'Shop New Arrivals',    ],
		2 => [ 'image' => $img_base, 'eyebrow' => 'Festival Collection', 'heading' => "Celebrate in\nTimeless Style",  'sub' => 'Exclusive festive kurtis — free delivery on all orders', 'cta' => 'Explore Festive Wear', ],
		3 => [ 'image' => $img_base, 'eyebrow' => 'Everyday Elegance',   'heading' => "From Pooja to\nBoardroom",      'sub' => 'Premium cotton & silk kurtis for every occasion',        'cta' => 'Shop Kurta Sets',      ],
		4 => [ 'image' => $img_base, 'eyebrow' => 'Limited Edition',     'heading' => "Crafted for\nEvery Moment",     'sub' => 'Discover pieces made to last beyond the season',         'cta' => 'Shop the Collection',  ],
		5 => [ 'image' => $img_base, 'eyebrow' => 'Just In',             'heading' => "Fresh Styles,\nTimeless Craft", 'sub' => 'New arrivals added every week',                          'cta' => 'See What\'s New',      ],
	];
}

function wk_render_interactive_hero() {
	if ( ! get_theme_mod( 'wk_show_hero', true ) ) return;

	$shop_url = class_exists( 'WooCommerce' ) ? get_permalink( wc_get_page_id( 'shop' ) ) : home_url( '/shop' );
	$defaults = wk_hero_defaults();
	$count    = max( 1, min( 5, (int) get_theme_mod( 'wk_hero_slide_count', 3 ) ) );

	$slides = [];
	for ( $i = 1; $i <= $count; $i++ ) {
		$d     = $defaults[ $i ];
		$image = get_theme_mod( "wk_hero{$i}_image", $d['image'] );
		$link  = get_theme_mod( "wk_hero{$i}_cta_link", '' );
		$slides[] = [
			'image'   => $image,
			'eyebrow' => get_theme_mod( "wk_hero{$i}_eyebrow", $d['eyebrow'] ),
			'heading' => get_theme_mod( "wk_hero{$i}_heading", $d['heading'] ),
			'sub'     => get_theme_mod( "wk_hero{$i}_sub", $d['sub'] ),
			'cta'     => get_theme_mod( "wk_hero{$i}_cta_text", $d['cta'] ),
			'link'    => $link ? $link : $shop_url,
		];
	}
	// Drop fully-empty slides (admin explicitly cleared every field) so a
	// deliberately-emptied slide never shows as a blank rectangle.
	$slides = array_values( array_filter( $slides, function( $s ) {
		return $s['image'] || $s['heading'] || $s['eyebrow'];
	} ) );
	if ( empty( $slides ) ) return;

	$total = count( $slides );
	?>
	<section class="wk-herobanner" id="wk-herobanner" aria-label="Featured collections" role="region">

		<div class="wk-herobanner__track" id="wk-herobanner-track">
		<?php foreach ( $slides as $idx => $s ) :
			$is_active = $idx === 0;
		?>
			<div class="wk-herobanner__slide<?php echo $is_active ? ' is-active' : ''; ?>"
			     data-index="<?php echo $idx; ?>"
			     aria-hidden="<?php echo $is_active ? 'false' : 'true'; ?>">

				<?php if ( $s['image'] ) : ?>
				<img class="wk-herobanner__bg" src="<?php echo esc_url( $s['image'] ); ?>"
				     alt="" loading="<?php echo $is_active ? 'eager' : 'lazy'; ?>"
				     fetchpriority="<?php echo $is_active ? 'high' : 'auto'; ?>" />
				<?php else : ?>
				<div class="wk-herobanner__bg wk-herobanner__bg--fallback" aria-hidden="true"></div>
				<?php endif; ?>

				<div class="wk-herobanner__scrim" aria-hidden="true"></div>

				<div class="wk-herobanner__body">
					<?php if ( $s['eyebrow'] ) : ?>
					<p class="wk-herobanner__eyebrow"><?php echo esc_html( $s['eyebrow'] ); ?></p>
					<?php endif; ?>

					<?php if ( $s['heading'] ) : ?>
					<h1 class="wk-herobanner__heading">
						<?php foreach ( explode( "\n", $s['heading'] ) as $line ) : ?>
						<span class="wk-herobanner__heading-line"><?php echo esc_html( trim( $line ) ); ?></span>
						<?php endforeach; ?>
					</h1>
					<?php endif; ?>

					<?php if ( $s['sub'] ) : ?>
					<p class="wk-herobanner__sub"><?php echo esc_html( $s['sub'] ); ?></p>
					<?php endif; ?>

					<?php if ( $s['cta'] ) : ?>
					<a href="<?php echo esc_url( $s['link'] ); ?>" class="wk-herobanner__cta">
						<?php echo esc_html( $s['cta'] ); ?>
						<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="13 6 19 12 13 18"/></svg>
					</a>
					<?php endif; ?>
				</div>

			</div><!-- /.wk-herobanner__slide -->
		<?php endforeach; ?>
		</div><!-- /.wk-herobanner__track -->

		<?php if ( $total > 1 ) : ?>
		<button class="wk-herobanner__nav wk-herobanner__nav--prev" id="wk-herobanner-prev" type="button" aria-label="Previous slide">
			<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
		</button>
		<button class="wk-herobanner__nav wk-herobanner__nav--next" id="wk-herobanner-next" type="button" aria-label="Next slide">
			<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
		</button>

		<div class="wk-herobanner__dots" role="tablist" aria-label="Slide indicators">
			<?php for ( $d = 0; $d < $total; $d++ ) : ?>
			<button class="wk-herobanner__dot<?php echo $d === 0 ? ' is-active' : ''; ?>"
			        type="button" role="tab"
			        data-index="<?php echo $d; ?>"
			        aria-label="Slide <?php echo $d + 1; ?>"
			        aria-selected="<?php echo $d === 0 ? 'true' : 'false'; ?>"></button>
			<?php endfor; ?>
		</div>
		<?php endif; ?>

	</section><!-- /.wk-herobanner -->
	<?php
}
