/* wk_params safe accessor */
window.wk_params = window.wk_params || { ajax_url: '/wp-admin/admin-ajax.php', nonce: '', shop_url: '/shop', checkout_url: '/checkout' };

/**
 * WhiteKurti — main.js
 * Handles: header scroll, mobile menu, cart drawer, search overlay,
 * filter drawer, product gallery, sticky ATC, AJAX add-to-cart, toast,
 * pincode checker, quantity buttons.
 */
(function ($) {
  'use strict';

  const wkP = window.wk_params || {};

  /* ── Utility ──────────────────────────────────────────────────────────── */
  function openOverlay(el) {
    el.classList.add('is-open');
    el.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    document.body.classList.add('wk-overlay-open');
    /* Hide notification popup when any overlay is open */
    var notif = document.getElementById('wk-fn-popup');
    if (notif) notif.style.display = 'none';
    var fEl = el.querySelector('[id$="-close"], .wk-icon-btn'); if (fEl) fEl.focus();
  }
  function closeOverlay(el) {
    el.classList.remove('is-open');
    el.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    document.body.classList.remove('wk-overlay-open');
  }
  function showToast(msg, duration) {
    duration = duration || 3000;
    const t = document.getElementById('wk-toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('is-visible');
    clearTimeout(t._tid);
    t._tid = setTimeout(function () { t.classList.remove('is-visible'); }, duration);
  }
  window.wkShowToast = showToast; // FIX v24: exposed so other script blocks (PDP add-to-cart) can reuse it

  /* ── Sticky header ────────────────────────────────────────────────────── */
  var header = document.getElementById('wk-header');
  if (header) {
    window.addEventListener('scroll', function () {
      header.classList.toggle('scrolled', window.scrollY > 10);
    }, { passive: true });
  }

  /* ── Mobile menu ──────────────────────────────────────────────────────── */
  var menuOverlay = document.getElementById('wk-menu-overlay');
  var menuToggle  = document.getElementById('wk-menu-toggle');
  var menuClose   = document.getElementById('wk-menu-close');
  var menuBack    = document.getElementById('wk-menu-backdrop');

  if (menuOverlay) {
    menuToggle && menuToggle.addEventListener('click', function () {
      openOverlay(menuOverlay);
      menuToggle.setAttribute('aria-expanded', 'true');
    });
    function closeMenu() {
      closeOverlay(menuOverlay);
      menuToggle && menuToggle.setAttribute('aria-expanded', 'false');
    }
    menuClose && menuClose.addEventListener('click', closeMenu);
    menuBack  && menuBack.addEventListener('click', closeMenu);
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && menuOverlay.classList.contains('is-open')) closeMenu();
    });
  }

  /* ── Cart drawer ──────────────────────────────────────────────────────── */
  var cartOverlay = document.getElementById('wk-cart-overlay');
  var cartToggle  = document.getElementById('wk-cart-toggle');
  var cartClose   = document.getElementById('wk-cart-close');
  var cartBack    = document.getElementById('wk-cart-backdrop');

  if (cartOverlay) {
    function openCart() { openOverlay(cartOverlay); cartToggle && cartToggle.setAttribute('aria-expanded','true'); }
    function closeCart() { closeOverlay(cartOverlay); cartToggle && cartToggle.setAttribute('aria-expanded','false'); }
    cartToggle && cartToggle.addEventListener('click', openCart);
    cartClose  && cartClose.addEventListener('click', closeCart);
    cartBack   && cartBack.addEventListener('click', closeCart);
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && cartOverlay.classList.contains('is-open')) closeCart();
    });
    // Open cart after successful add
    $(document.body).on('wc_cart_button_updated added_to_cart', function () {
      openCart();
    });
  }

  /* ── Search overlay ───────────────────────────────────────────────────── */
  var searchOverlay  = document.getElementById('wk-search-overlay');
  var searchToggle   = document.getElementById('wk-search-toggle');
  var searchClose    = document.getElementById('wk-search-close');
  var searchBack     = document.getElementById('wk-search-backdrop');
  var searchInput    = document.getElementById('wk-search-input');

  if (searchOverlay) {
    function openSearch() {
      openOverlay(searchOverlay);
      searchToggle && searchToggle.setAttribute('aria-expanded','true');
      setTimeout(function () { searchInput && searchInput.focus(); }, 100);
    }
    function closeSearch() {
      closeOverlay(searchOverlay);
      searchToggle && searchToggle.setAttribute('aria-expanded','false');
    }
    searchToggle && searchToggle.addEventListener('click', openSearch);
    searchClose  && searchClose.addEventListener('click', closeSearch);
    searchBack   && searchBack.addEventListener('click', closeSearch);
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && searchOverlay.classList.contains('is-open')) closeSearch();
    });

    // ── Rich Live Search ─────────────────────────────────────
    if (searchInput) {
      var lsCfg     = window.wk_search_cfg || {};
      var lsEnabled = lsCfg.enabled !== '0';
      var minChars  = parseInt(lsCfg.min_chars, 10) || 2;
      var debounceMs= parseInt(lsCfg.debounce, 10)  || 280;
      var shopUrl   = lsCfg.shop_url || '/shop/';
      var lsTimer;
      var lsFocused = -1;
      var lsResults = document.getElementById('wk-search-results');
      var RECENT_KEY= 'wk_recent_searches';

      function getRecent() {
        try { return JSON.parse(localStorage.getItem(RECENT_KEY) || '[]'); } catch(e) { return []; }
      }
      function addRecent(q) {
        var rec = getRecent().filter(function(r){ return r !== q; });
        rec.unshift(q);
        try { localStorage.setItem(RECENT_KEY, JSON.stringify(rec.slice(0,8))); } catch(e) {}
      }

      function buildProductHTML(p, showPrice, showCat) {
        var saleTag = p.on_sale ? '<span class="wk-sr-product__sale" style="font-size:10px;background:var(--sale);color:#fff;padding:1px 5px;border-radius:2px;margin-left:4px;">SALE</span>' : '';
        var stock   = !p.in_stock ? '<span class="wk-sr-product__stock-oos">Out of stock</span>' : '';
        return '<a href="' + p.url + '" class="wk-sr-product">'
          + '<img src="' + p.img + '" alt="' + (p.name||'') + '" class="wk-sr-product__img" loading="lazy" />'
          + '<div class="wk-sr-product__info">'
            + '<span class="wk-sr-product__name">' + p.name + saleTag + '</span>'
            + (showCat && p.cat ? '<span class="wk-sr-product__cat">' + p.cat + '</span>' : '')
            + stock
          + '</div>'
          + (showPrice ? '<div class="wk-sr-product__right"><span class="wk-sr-product__price">' + p.price + '</span></div>' : '')
          + '</a>';
      }

      function showDefault() {
        if (!lsResults) return;
        var html = '';
        // Recent searches
        if (lsCfg.show_recent !== '0') {
          var recent = getRecent();
          if (recent.length) {
            html += '<div class="wk-sr-section"><div class="wk-sr-section__label">⏱ Recent</div><div class="wk-sr-tags">';
            recent.slice(0,5).forEach(function(r) {
              html += '<a href="' + shopUrl + '?s=' + encodeURIComponent(r) + '" class="wk-sr-tag">'+r+'</a>';
            });
            html += '</div></div>';
          }
        }
        // Trending
        if (lsCfg.show_trending !== '0' && lsCfg.trending && lsCfg.trending.length) {
          html += '<div class="wk-sr-section"><div class="wk-sr-section__label">🔥 Trending</div><div class="wk-sr-tags">';
          lsCfg.trending.forEach(function(t) {
            if (t) html += '<a href="' + shopUrl + '?s=' + encodeURIComponent(t) + '" class="wk-sr-tag">' + t + '</a>';
          });
          html += '</div></div>';
        }
        lsResults.innerHTML = html || '';
      }

      function doSearch(q) {
        if (!lsResults) return;
        lsResults.innerHTML = '<div class="wk-sr-loading"><div class="wk-sr-spinner"></div></div>';

        $.post(lsCfg.ajax || wkP.ajax_url, {
          action: 'wk_live_search',
          nonce:  lsCfg.nonce,
          q:      q,
        }, function(res) {
          if (!res.success) { lsResults.innerHTML = '<div class="wk-sr-empty"><span class="wk-sr-empty__icon">🔍</span>No results found for "<strong>' + q + '</strong>"</div>'; return; }
          var d   = res.data;
          var html= '';
          var showPrice = lsCfg.show_price !== '0';
          var showCat   = lsCfg.show_cat   !== '0';

          // Products
          if (d.products && d.products.length) {
            html += '<div class="wk-sr-section"><div class="wk-sr-section__label">👗 Products</div>';
            d.products.forEach(function(p) { html += buildProductHTML(p, showPrice, showCat); });
            html += '</div>';
          }
          // Categories
          if (d.categories && d.categories.length) {
            html += '<div class="wk-sr-section"><div class="wk-sr-section__label">📂 Categories</div>';
            d.categories.forEach(function(c) {
              html += '<a href="' + c.url + '" class="wk-sr-cat">'
                + (c.img ? '<img src="'+c.img+'" alt="'+c.name+'" class="wk-sr-cat__img" />' : '')
                + '<span class="wk-sr-cat__name">' + c.name + '</span>'
                + '<span class="wk-sr-cat__count">' + c.count + ' items</span>'
                + '</a>';
            });
            html += '</div>';
          }
          // Pages
          if (d.pages && d.pages.length) {
            html += '<div class="wk-sr-section"><div class="wk-sr-section__label">📄 Pages</div>';
            d.pages.forEach(function(p) {
              html += '<a href="'+p.url+'" class="wk-sr-page"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>'+p.name+'</a>';
            });
            html += '</div>';
          }
          // Nothing found
          if (!d.products.length && !d.categories.length && !d.pages.length) {
            html = '<div class="wk-sr-empty"><span class="wk-sr-empty__icon">🔍</span>No results for "<strong>' + q + '</strong>"<br><span style="font-size:12px;opacity:.6">Try a different term or browse all products</span></div>';
          } else {
            html += '<a href="' + shopUrl + '?s=' + encodeURIComponent(q) + '" class="wk-sr-view-all">View all results for "' + q + '" <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>';
          }
          lsResults.innerHTML = html;
          lsFocused = -1;
        }).fail(function() {
          if (lsResults) lsResults.innerHTML = '<div class="wk-sr-empty">Connection error. Please try again.</div>';
        });
      }

      // Input events
      searchInput.addEventListener('focus', function() {
        if (!this.value.trim()) showDefault();
      });
      searchInput.addEventListener('input', function() {
        clearTimeout(lsTimer);
        var q = this.value.trim();
        if (!q || q.length < minChars) {
          if (!q) showDefault();
          else if (lsResults) lsResults.innerHTML = '';
          return;
        }
        lsTimer = setTimeout(function() { doSearch(q); }, debounceMs);
      });

      // Keyboard navigation
      searchInput.addEventListener('keydown', function(e) {
        var items = lsResults ? lsResults.querySelectorAll('.wk-sr-product, .wk-sr-cat, .wk-sr-page, .wk-sr-tag, .wk-sr-view-all') : [];
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          lsFocused = Math.min(lsFocused + 1, items.length - 1);
          items.forEach(function(el, i) { el.classList.toggle('is-focused', i === lsFocused); });
          if (items[lsFocused]) items[lsFocused].scrollIntoView({block:'nearest'});
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          lsFocused = Math.max(lsFocused - 1, -1);
          items.forEach(function(el, i) { el.classList.toggle('is-focused', i === lsFocused); });
        } else if (e.key === 'Enter' && lsFocused >= 0 && items[lsFocused]) {
          e.preventDefault();
          items[lsFocused].click();
        }
      });

      // Save recent on form submit
      searchInput.closest('form') && searchInput.closest('form').addEventListener('submit', function() {
        var q = searchInput.value.trim();
        if (q) addRecent(q);
      });

      // Close on click outside
      document.addEventListener('click', function(e) {
        if (lsResults && !lsResults.contains(e.target) && e.target !== searchInput) {
          lsResults.innerHTML = '';
        }
      });
    }
  }

  /* ── Filter drawer ────────────────────────────────────────────────────── */
  var filterDrawer   = document.getElementById('wk-filter-drawer');
  var filterToggle   = document.getElementById('wk-filter-toggle');
  var filterClose    = document.getElementById('wk-filter-close');
  var filterBack     = document.getElementById('wk-filter-backdrop');

  if (filterDrawer) {
    function openFilter() { filterDrawer.classList.add('is-open'); document.body.style.overflow = 'hidden'; filterToggle && filterToggle.setAttribute('aria-expanded','true'); }
    function closeFilter() { filterDrawer.classList.remove('is-open'); document.body.style.overflow = ''; filterToggle && filterToggle.setAttribute('aria-expanded','false'); }
    filterToggle && filterToggle.addEventListener('click', openFilter);
    filterClose  && filterClose.addEventListener('click', closeFilter);
    filterBack   && filterBack.addEventListener('click', closeFilter);
    var filterApply = document.getElementById('wk-filter-apply');
    filterApply && filterApply.addEventListener('click', closeFilter);
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeFilter();
    });
  }

  /* ── Product gallery (PDP) ────────────────────────────────────────────── */
  // Handled by standalone IIFE below (after main IIFE ends)

  /* ── Sticky ATC (PDP, mobile) ─────────────────────────────────────────── */
  var stickyAtc = document.getElementById('wk-sticky-atc');
  // Observe the Buy Now button (which is always in the info section) for sticky ATC visibility
  var atcSection = document.getElementById('wk-buy-now') || document.getElementById('wk-atc-btn') || document.querySelector('.wk-pdp__info');
  if (stickyAtc && atcSection) {
    var stickyObserver = new IntersectionObserver(function (entries) {
      stickyAtc.classList.toggle('is-visible', !entries[0].isIntersecting);
    }, { threshold: 0 });
    stickyObserver.observe(atcSection);
    // Click handling for #wk-sticky-atc-btn lives in the "PRODUCT PAGE" module
    // further down (wkAddToCartAjax) — kept in one place, AJAX-based.
  }

  /* ── Quantity buttons ─────────────────────────────────────────────────── */
  $(document.body).on('click', '.qty-btn', function () {
    var $btn   = $(this);
    var $input = $btn.closest('.quantity').find('input.qty');
    var val    = parseInt($input.val()) || 1;
    var next   = $btn.data('dir') === 'up' ? val + 1 : Math.max(1, val - 1);
    $input.val(next);

    // FIX: this used to only change the number shown in the box — nothing
    // told the server the quantity had actually changed. That's exactly
    // how the per-row "Total" column and the separate "Cart Totals" box
    // beside it could go on quietly disagreeing with each other: the
    // change here was purely visual until a shopper happened to notice
    // and click "Update Cart" by hand. If this input belongs to a real
    // WooCommerce cart line (name="cart[key][qty]"), push the change
    // through the same real-time endpoint used by the mini-cart drawer
    // and checkout, so the cart page is never left showing a number that
    // isn't what's actually saved.
    var nameAttr = $input.attr('name') || '';
    var m = nameAttr.match(/^cart\[([^\]]+)\]\[qty\]$/);
    if (m && window.wkUpdateCartItem) {
      var cartKey = m[1];
      var $row = $btn.closest('tr.cart_item, .woocommerce-cart-form__cart-item');
      $row.css('opacity', '0.5');
      window.wkUpdateCartItem(cartKey, next).then(function() {
        // Reload so the row subtotal, the Cart Totals box, and the mini
        // cart are all guaranteed to reflect the exact same, freshly
        // recalculated state — rather than trying to patch several
        // separate bits of the page by hand and risking them drifting
        // apart again.
        window.location.reload();
      });
    } else {
      $input.trigger('change');
    }
  });

  /* Inject +/- buttons around qty inputs */
  $(document.body).on('woocommerce_quantity_input_init updated_wc_div', function () {
    $('.quantity').each(function () {
      if (!$(this).find('.qty-btn').length) {
        $(this).find('input.qty').wrap('<div class="qty-inner"></div>');
        $(this).prepend('<button class="qty-btn" data-dir="down" aria-label="Decrease quantity" type="button">−</button>');
        $(this).append('<button class="qty-btn" data-dir="up" aria-label="Increase quantity" type="button">+</button>');
      }
    });
  }).trigger('woocommerce_quantity_input_init');

  /* ── AJAX Add to Cart ─────────────────────────────────────────────────── */
  // FIX v24: .wk-rec-card__atc (the "Add to Cart" button on the PDP's "You
  // May Also Like" section) had no click handler at all — it rendered but
  // did nothing when clicked. Same markup pattern as .wk-quick-atc
  // (product_id + simple products only), so one handler covers both.
  $(document.body).on('click', '.wk-quick-atc, .wk-rec-card__atc', function (e) {
    e.preventDefault();
    var $btn = $(this);
    var pid  = $btn.data('product-id');
    if (!pid || !wkP.ajax_url) return;
    var originalText = $btn.text();
    $btn.prop('disabled', true).text('Adding…');
    $.ajax({
      url:      wkP.ajax_url,
      method:   'POST',
      data: {
        action:     'wk_add_to_cart',
        nonce:      wkP.nonce,
        product_id: pid,
        quantity:   1,
      },
      success: function (res) {
        $btn.prop('disabled', false).text('Added!');
        setTimeout(function () { $btn.text(originalText); }, 2000);
        if (res.success) {
          if (typeof window.wkPlayAddToCartSound === 'function') window.wkPlayAddToCartSound();
          // FIX v27: this quick-add button (product grid / "You May Also
          // Like") updated the cart *count* badge below, but never actually
          // applied the returned fragments to the page — so the drawer's
          // item list and subtotal stayed exactly as they were before the
          // click, even though the drawer itself popped open right after.
          // Every other add-to-cart entry point in the theme calls
          // wkApplyFragments(); this one just forgot to.
          if (window.wkApplyFragments) window.wkApplyFragments(res.data.fragments);
          $(document.body).trigger('added_to_cart', [res.data.fragments, res.data.cart_hash, $btn]);
          // Update cart count
          var count = res.data.cart_count;
          $('.wk-cart-count').text(count).toggleClass('has-items', count > 0);
          showToast(wkP.i18n_added || 'Added to cart');
        } else {
          showToast(wkP.i18n_error || 'Error adding to cart');
        }
      },
      error: function () {
        $btn.prop('disabled', false).text(originalText);
        showToast(wkP.i18n_error || 'Error adding to cart');
      }
    });
  });

  /* ── Pincode checker (PDP) ─────────────────────────────────────────────── */
  // FIX v24: this used to fake the result with a hardcoded setTimeout message
  // regardless of the pincode entered. There's a complete, real backend for
  // this already (delivery zones, express areas, COD exclusions, business-day
  // delivery dates) sitting unused in inc/pincode-delivery.php — wired it up.
  var pincodeCheckBtn = document.getElementById('wk-pincode-check');
  var pincodeInput    = document.getElementById('wk-pincode-input');
  var pincodeResult   = document.getElementById('wk-pincode-result');

  if (pincodeCheckBtn && pincodeInput && pincodeResult) {
    pincodeCheckBtn.addEventListener('click', function () {
      var pin = pincodeInput.value.trim();
      if (!/^\d{6}$/.test(pin)) {
        pincodeResult.textContent = 'Please enter a valid 6-digit pincode.';
        pincodeResult.style.color = 'var(--sale)';
        return;
      }
      var cfg = window.wk_pincode_cfg || {};
      if (!cfg.ajax || !cfg.nonce) {
        // Config not localized (e.g. feature disabled) — fail gracefully
        pincodeResult.style.color = 'var(--sale)';
        pincodeResult.textContent = 'Delivery check is unavailable right now.';
        return;
      }
      pincodeCheckBtn.disabled = true;
      var originalLabel = pincodeCheckBtn.textContent;
      pincodeCheckBtn.textContent = '…';

      fetch(cfg.ajax, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=wk_check_pincode&pincode=' + encodeURIComponent(pin) + '&nonce=' + encodeURIComponent(cfg.nonce)
      }).then(function(r) { return r.json(); })
      .then(function(data) {
        pincodeCheckBtn.disabled = false;
        pincodeCheckBtn.textContent = originalLabel;
        if (data && data.success) {
          var extras = [];
          if (data.data.free) extras.push('Free delivery');
          if (data.data.cod) extras.push('COD available');
          pincodeResult.style.color = 'var(--accent)';
          pincodeResult.textContent = '✓ ' + data.data.message + (extras.length ? ' · ' + extras.join(' · ') : '');
        } else {
          pincodeResult.style.color = 'var(--sale)';
          pincodeResult.textContent = (data && data.data && data.data.message) || 'Delivery not available to this pincode.';
        }
      }).catch(function() {
        pincodeCheckBtn.disabled = false;
        pincodeCheckBtn.textContent = originalLabel;
        pincodeResult.style.color = 'var(--sale)';
        pincodeResult.textContent = 'Could not check delivery right now. Please try again.';
      });
    });
    pincodeInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') pincodeCheckBtn.click();
    });
  }

  /* ── Wishlist toggle (UI state only — server state needs YITH plugin) ─── */
  // FIX v24: the theme has two wishlist button markups — .wk-wish-btn (shop
  // grid cards, via wk_product_card()) and .wk-wl-btn (the canonical
  // wk_wishlist_button() helper, used on PDP related products). Only the
  // first was wired up, so the second did nothing when clicked.
  $(document.body).on('click', '.wk-wish-btn, .wk-wl-btn', function () {
    var $btn = $(this);
    var productId = $btn.data('product-id') || $btn.attr('data-product-id');
    if (!productId) return;
    var adding = !$btn.hasClass('is-wished') && !$btn.hasClass('is-in-wishlist');
    // FIX v24: .wk-wish-btn uses .is-wished/.active for its filled-heart
    // state, .wk-wl-btn uses .is-in-wishlist — toggle all of them so either
    // markup gets the correct visual feedback.
    $btn.toggleClass('is-wished active is-in-wishlist', adding);
    $btn.attr('aria-pressed', adding ? 'true' : 'false');
    showToast(adding ? '❤️ Added to wishlist' : 'Removed from wishlist');

    /* Custom wishlist AJAX (built-in, no YITH needed) */
    var wlCfg = window.wk_wishlist_cfg;
    if (wlCfg && wlCfg.nonce) {
      $.ajax({
        url: wlCfg.ajax || (window.wk_params && window.wk_params.ajax_url) || '/wp-admin/admin-ajax.php',
        method: 'POST',
        data: { action: 'wk_wishlist_toggle', product_id: productId, nonce: wlCfg.nonce }
      });
    }
  });

  /* ── Apply WooCommerce-style fragments (selector → HTML) directly ───────
     FIX: add-to-cart / quantity changes used to only fire the generic
     `wc_fragment_refresh` event and hope WooCommerce's own bundled
     cart-fragments script picked it up with a *second* round-trip AJAX
     call. That extra hop was a common point of failure — if that script
     wasn't loaded/localized exactly right, the mini-cart drawer would
     silently keep showing stale contents even though the item really had
     been added (which is exactly why the main cart page could be correct
     while the sidebar drawer wasn't). We already get the correct fragments
     back directly in our own AJAX response, so just apply them ourselves,
     immediately, with no dependency on a second request. ────────────────── */
  function wkApplyFragments(fragments) {
    if (!fragments) return;
    Object.keys(fragments).forEach(function(selector) {
      var html = fragments[selector];
      if (!html) return;
      try {
        if (window.jQuery) {
          jQuery(selector).replaceWith(html);
        } else {
          var node = document.querySelector(selector);
          if (node) {
            var tmp = document.createElement('div');
            tmp.innerHTML = html;
            var replacement = tmp.firstElementChild;
            if (replacement) node.replaceWith(replacement);
          }
        }
      } catch (e) { /* ignore a single bad fragment, others still apply */ }
    });
  }

  /* ── Quantity stepper + remove — shared by mini-cart, cart page rows,
     and the checkout "Your Order" review. All three render the exact same
     .wk-qty-stepper / .wk-order-review-item__remove / .wk-mini-cart-item__remove
     markup, so one delegated handler covers every instance, including ones
     that get swapped in later via wkApplyFragments(). ────────────────────── */
  function wkUpdateCartItem(cartItemKey, quantity, opts) {
    opts = opts || {};
    var p = window.wk_params || {};
    return fetch(p.ajax_url || '/wp-admin/admin-ajax.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'action=wk_update_cart_item&cart_item_key=' + encodeURIComponent(cartItemKey) +
            '&quantity=' + encodeURIComponent(quantity) +
            (opts.remove ? '&remove=1' : '') +
            '&nonce=' + encodeURIComponent(p.nonce || '')
    }).then(function(r) { return r.json(); })
      .then(function(data) {
        if (data && data.success) {
          wkApplyFragments(data.data && data.data.fragments);
          if (window.jQuery) {
            jQuery(document.body).trigger('wc_fragment_refresh');
          }
          // On checkout, quantities/removals also change shipping, tax and
          // payment-method availability — let WooCommerce's own checkout
          // JS recalculate that via its native refresh, now that the cart
          // itself has already been updated server-side above.
          if (document.body.classList.contains('woocommerce-checkout') && window.jQuery) {
            jQuery(document.body).trigger('update_checkout');
          }
        } else if (window.wkShowToast) {
          wkShowToast((data && data.data && data.data.message) || 'Could not update your cart.');
        }
        return data;
      })
      .catch(function() {
        if (window.wkShowToast) wkShowToast('Could not update your cart. Please try again.');
      });
  }
  // Exposed so other script blocks (e.g. the PDP add-to-cart handler further
  // down this file, in its own separate closure) can reuse the same
  // fragment-application logic instead of duplicating it.
  window.wkApplyFragments = wkApplyFragments;
  window.wkUpdateCartItem = wkUpdateCartItem;

  $(document.body).on('click', '.wk-qty-stepper__btn', function() {
    var $btn     = $(this);
    var $stepper = $btn.closest('.wk-qty-stepper');
    var cartKey  = $stepper.data('cart-key');
    if (!cartKey || $stepper.hasClass('is-updating')) return;
    var $value   = $stepper.find('.wk-qty-stepper__value');
    var current  = parseInt($value.text(), 10) || 1;
    var next     = $btn.hasClass('wk-qty-stepper__btn--plus') ? current + 1 : current - 1;
    if (next < 0) return;
    $stepper.addClass('is-updating');
    wkUpdateCartItem(cartKey, next, { remove: next === 0 }).then(function() {
      $stepper.removeClass('is-updating');
    });
  });

  /* ── Mini-cart / order-review item remove (real-time, no page reload) ─── */
  $(document.body).on('click', '.wk-mini-cart-item__remove, .wk-order-review-item__remove', function (e) {
    e.preventDefault();
    var $btn = $(this);
    var cartKey = $btn.data('cart-key');
    if (!cartKey) return;
    var $item = $btn.closest('.wk-mini-cart-item, .woocommerce-cart-form__cart-item, tr');
    $item.css('opacity', '0.4');
    wkUpdateCartItem(cartKey, 0, { remove: true });
  });

  /* ── Accordion (details/summary) — ensure only one open at a time ──────── */
  document.querySelectorAll('.wk-pdp__accordions').forEach(function (container) {
    container.addEventListener('toggle', function (e) {
      if (e.target.open) {
        container.querySelectorAll('details.wk-accordion').forEach(function (d) {
          if (d !== e.target) d.open = false;
        });
      }
    }, true);
  });

  /* ── Back-to-top (keyboard escape from deep pages) ─────────────────────── */
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      // close all open overlays in order of priority
      var order = [cartOverlay, searchOverlay, menuOverlay];
      for (var i = 0; i < order.length; i++) {
        if (order[i] && order[i].classList.contains('is-open')) {
          order[i].classList.remove('is-open');
          order[i].setAttribute('aria-hidden', 'true');
          document.body.style.overflow = '';
          break;
        }
      }
    }
  });

  /* ── WooCommerce fragments update ─────────────────────────────────────── */
  $(document.body).on('wc_fragments_refreshed wc_fragments_loaded', function () {
    var count = parseInt($('.wk-cart-count').text()) || 0;
    $('.wk-cart-count').toggleClass('has-items', count > 0);
  });

  /* ── Auth Tabs (Login/Register) ────────────────────────────────────────── */
  var authTabs = document.querySelectorAll('.wk-auth-tab');
  if (authTabs.length > 0) {
    authTabs.forEach(function(tab) {
      tab.addEventListener('click', function() {
        var target = document.querySelector(this.getAttribute('data-target'));
        if (!target) return;
        
        // Remove active from all tabs and panes
        document.querySelectorAll('.wk-auth-tab').forEach(function(t) { t.classList.remove('is-active'); });
        document.querySelectorAll('.wk-auth-form-pane').forEach(function(p) { p.classList.remove('is-active'); });
        
        // Add active to current
        this.classList.add('is-active');
        target.classList.add('is-active');
      });
    });
  }

  /* ── Variable Swatches Logic ───────────────────────────────────────────── */
  $(document.body).on('click', '.wk-swatch', function() {
    var $swatch = $(this);
    var value = $swatch.data('value');
    var selectId = $swatch.closest('.wk-swatches').data('select-id');
    var $select = $('#' + selectId);
    
    // Update UI
    $swatch.siblings().removeClass('is-selected');
    $swatch.addClass('is-selected');
    
    // Update native select and trigger WooCommerce change event
    $select.val(value).trigger('change');
  });

  // Handle WooCommerce reset variations
  $(document.body).on('reset_data', function() {
    $('.wk-swatch').removeClass('is-selected');
  });

}(jQuery));


/* ══════════════════════════════════════════════════════════════
   PRODUCT GALLERY — Swipe + Thumbnails + Zoom + Lightbox
   ══════════════════════════════════════════════════════════════ */
(function() {
  var track    = document.getElementById('wk-gallery-track');
  var mainEl   = document.getElementById('wk-gallery-main');
  if (!track || !mainEl) return;

  // Height is defined by the image's own aspect-ratio CSS.
  // No JS height setting needed — prevents the '0px height' bug.

  var slides   = Array.prototype.slice.call(track.querySelectorAll('.wk-gallery-slide'));
  var thumbs   = Array.prototype.slice.call(document.querySelectorAll('.wk-gallery-thumb'));
  var dots     = Array.prototype.slice.call(document.querySelectorAll('.wk-gallery-dot'));
  var counter  = document.getElementById('wk-gallery-counter');
  var prevBtn  = document.getElementById('wk-gallery-prev');
  var nextBtn  = document.getElementById('wk-gallery-next');
  var expandBtn= document.getElementById('wk-gallery-expand');
  var total    = slides.length;
  var cur      = 0;
  var isTouch  = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);

  /* ── Initialize slide widths explicitly ────────────────────── */
  function _initSlides() {
    // Use rAF to ensure aspect-ratio container has resolved its height first
    requestAnimationFrame(function() {
      var w = mainEl.offsetWidth;
      if (w > 0) {
        slides.forEach(function(sl) {
          sl.style.minWidth = w + 'px';
          sl.style.width    = w + 'px';
        });
        goTo(cur, true);
      }
    });
  }
  /* Run after layout is settled - use two rAF calls for maximum reliability */
  function _scheduleInit() {
    requestAnimationFrame(function() {
      requestAnimationFrame(function() {
        _initSlides();
      });
    });
  }
  if (document.readyState === 'complete') {
    _scheduleInit();
  } else {
    window.addEventListener('load', _scheduleInit);
  }
  /* Also run immediately in case styles are already computed */
  _scheduleInit();
  // ResizeObserver (modern) for accurate gallery resize handling
  if (typeof ResizeObserver !== 'undefined') {
    var _resizeObs = new ResizeObserver(function() {
      _initSlides();
      goTo(cur, true);
    });
    _resizeObs.observe(mainEl);
  } else {
    window.addEventListener('resize', function() { _initSlides(); goTo(cur, true); });
  }

  /* ── Navigate to slide n ────────────────────────────────────── */
  function goTo(n, noAnim) {
    cur = ((n % total) + total) % total;
    if (noAnim) { track.classList.add('no-transition'); }
    // Use px offset for accuracy when slides have explicit px widths
    var slideW = slides.length > 0 ? (slides[0].offsetWidth || mainEl.offsetWidth) : mainEl.offsetWidth;
    track.style.transform = 'translateX(-' + (cur * slideW) + 'px)';
    if (noAnim) { track.offsetHeight; track.classList.remove('no-transition'); }

    if (counter) counter.textContent = (cur + 1) + ' / ' + total;

    thumbs.forEach(function(t, i) { t.classList.toggle('is-active', i === cur); });
    dots.forEach(function(d, i)   { d.classList.toggle('is-active', i === cur); });

    if (thumbs[cur]) {
      thumbs[cur].scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
    }
    updateZoom();
  }

  /* ── Thumbnail clicks ───────────────────────────────────────── */
  thumbs.forEach(function(t) {
    t.addEventListener('click', function() { goTo(parseInt(this.dataset.index, 10)); });
  });
  dots.forEach(function(d) {
    d.addEventListener('click', function() { goTo(parseInt(this.dataset.index, 10)); });
  });
  if (prevBtn) prevBtn.addEventListener('click', function() { goTo(cur - 1); });
  if (nextBtn) nextBtn.addEventListener('click', function() { goTo(cur + 1); });

  /* ── Keyboard ───────────────────────────────────────────────── */
  document.addEventListener('keydown', function(e) {
    if (document.querySelector('.wk-lightbox')) return;
    if (!document.getElementById('wk-gallery-main')) return;
    if (e.key === 'ArrowLeft')  { e.preventDefault(); goTo(cur - 1); }
    if (e.key === 'ArrowRight') { e.preventDefault(); goTo(cur + 1); }
  });

  /* ── Touch/Mouse swipe ──────────────────────────────────────── */
  var sx = 0, sy = 0, dx = 0, swiping = false, locked = false;

  function dragStart(cx, cy) {
    sx = cx; sy = cy; dx = 0; swiping = true; locked = false;
    track.style.transition = 'none';
  }
  function dragMove(cx, cy) {
    if (!swiping) return;
    dx = cx - sx;
    var dy = cy - sy;
    if (!locked) {
      if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;
      if (Math.abs(dy) > Math.abs(dx)) { swiping = false; track.style.transition = ''; return; }
      locked = true;
    }
    var rubber = ((cur === 0 && dx > 0) || (cur === total - 1 && dx < 0)) ? 0.25 : 1;
    var slideW2 = slides.length > 0 ? (slides[0].offsetWidth || mainEl.offsetWidth) : mainEl.offsetWidth;
    track.style.transform = 'translateX(calc(-' + (cur * slideW2) + 'px + ' + (dx * rubber) + 'px))';
  }
  function dragEnd() {
    if (!swiping) return;
    swiping = false; locked = false;
    track.style.transition = '';
    var threshold = mainEl.offsetWidth * 0.2;
    if (dx < -threshold)     goTo(cur + 1);
    else if (dx > threshold) goTo(cur - 1);
    else                     goTo(cur);
  }

  track.addEventListener('touchstart', function(e) { dragStart(e.touches[0].clientX, e.touches[0].clientY); }, { passive: true });
  track.addEventListener('touchmove',  function(e) {
    dragMove(e.touches[0].clientX, e.touches[0].clientY);
    if (locked && e.cancelable) e.preventDefault();
  }, { passive: false });
  track.addEventListener('touchend',   function(e) { dx = e.changedTouches[0].clientX - sx; dragEnd(); }, { passive: true });
  track.addEventListener('touchcancel', dragEnd, { passive: true });

  track.addEventListener('mousedown', function(e) { dragStart(e.clientX, e.clientY); e.preventDefault(); });
  document.addEventListener('mousemove', function(e) { dragMove(e.clientX, e.clientY); });
  document.addEventListener('mouseup',   function(e) { dx = e.clientX - sx; dragEnd(); });

  /* ── Hover zoom (desktop only) ──────────────────────────────── */
  var cfg     = window.wk_zoom_cfg || {};
  var zEnabled= !isTouch && cfg.enabled === '1' && window.innerWidth >= 768;
  var panelEl = document.getElementById('wk-zoom-panel');
  var panelImg= document.getElementById('wk-zoom-img');
  var lensEl  = null;

  function updateZoom() {
    if (!zEnabled || !panelImg) return;
    var slide = slides[cur];
    if (!slide) return;
    var img = slide.querySelector('.wk-gallery-img');
    panelImg.src = (img && img.getAttribute('data-full')) || (img && img.src) || '';
  }

  if (zEnabled && panelEl) {
    var lensSize = parseInt(cfg.lens_size, 10) || 110;
    var magnify  = parseFloat(cfg.magnify)     || 2.5;

    lensEl = document.createElement('div');
    lensEl.className = 'wk-zoom-lens';
    lensEl.style.cssText = 'width:' + lensSize + 'px;height:' + lensSize + 'px;border-radius:50%;position:absolute;pointer-events:none;display:none;';
    mainEl.appendChild(lensEl);
    panelEl.style.display = 'none';

    mainEl.addEventListener('mouseenter', function() {
      updateZoom();
      lensEl.style.display = 'block';
      panelEl.style.display = 'block';
      mainEl.style.cursor = 'crosshair';
    });
    mainEl.addEventListener('mouseleave', function() {
      lensEl.style.display = 'none';
      panelEl.style.display = 'none';
      mainEl.style.cursor = '';
    });
    mainEl.addEventListener('mousemove', function(e) {
      var r = mainEl.getBoundingClientRect();
      var x = e.clientX - r.left, y = e.clientY - r.top;
      var hw = lensSize / 2;
      x = Math.max(hw, Math.min(r.width - hw, x));
      y = Math.max(hw, Math.min(r.height - hw, y));
      lensEl.style.left = (x - hw) + 'px';
      lensEl.style.top  = (y - hw) + 'px';
      if (panelImg && panelImg.src) {
        var pw = panelEl.offsetWidth || 400, ph = panelEl.offsetHeight || 400;
        panelImg.style.cssText = 'position:absolute;width:' + (r.width*magnify) + 'px;height:' + (r.height*magnify) + 'px;' +
          'left:' + -(x*magnify - pw/2) + 'px;top:' + -(y*magnify - ph/2) + 'px;max-width:none;pointer-events:none;';
      }
    });
    updateZoom();
  }

  /* ── Lightbox ───────────────────────────────────────────────── */
  function openLightbox(startIdx) {
    var imgs = slides.map(function(s) {
      var img = s.querySelector('.wk-gallery-img');
      return { src: s.dataset.full || (img && img.src) || '', alt: img ? img.alt : '' };
    }).filter(function(i) { return i.src; });
    if (!imgs.length) return;

    var lbIdx = startIdx != null ? startIdx : cur;
    var lb = document.createElement('div');
    lb.className = 'wk-lightbox';
    lb.setAttribute('role', 'dialog');
    lb.setAttribute('aria-modal', 'true');
    // Belt-and-braces: force this above absolutely everything else on the
    // page via inline style, so it can never be visually covered by any
    // other fixed-position element regardless of what z-index that
    // element's own CSS happens to carry (this theme has several
    // independent z-index scales defined in different places).
    lb.style.zIndex = '2147483647';

    var slideWidthPct = 100 / imgs.length;
    var slides_html = imgs.map(function(img, i) {
      return '<div class="wk-lightbox__slide" style="width:' + slideWidthPct + '%;flex:0 0 ' + slideWidthPct + '%;min-width:0;">' +
        '<img class="wk-lightbox__img" src="' + img.src + '" alt="' + img.alt + '" loading="eager"/></div>';
    }).join('');

    lb.innerHTML =
      '<div class="wk-lightbox__viewport" style="position:relative;width:100%;height:100%;overflow:hidden;">' +
        '<div class="wk-lightbox__track" style="display:flex;width:' + (imgs.length * 100) + '%;height:100%;transition:transform .3s ease;" id="wk-lb-track">' +
          slides_html +
        '</div>' +
      '</div>' +
      '<button class="wk-lightbox__close" aria-label="Close">&times;</button>' +
      (imgs.length > 1 ? '<button class="wk-lightbox__nav wk-lightbox__prev">&#8249;</button><button class="wk-lightbox__nav wk-lightbox__next">&#8250;</button>' : '') +
      '<div class="wk-lightbox__counter">' + (lbIdx+1) + ' / ' + imgs.length + '</div>';

    document.body.appendChild(lb);
    document.body.style.overflow = 'hidden';

    var lbTrack   = lb.querySelector('.wk-lightbox__track');
    var lbCounter = lb.querySelector('.wk-lightbox__counter');

    function lbGoTo(n) {
      lbIdx = ((n % imgs.length) + imgs.length) % imgs.length;
      // Each step moves by ONE slide-width, which is (100/N)% of the
      // TRACK's own width (translateX's percentage is relative to the
      // element it's applied to) — not a flat 100%, since the track
      // itself is N*100% wide, not 100%.
      lbTrack.style.transform = 'translateX(-' + (lbIdx * slideWidthPct) + '%)';
      if (lbCounter) lbCounter.textContent = (lbIdx+1) + ' / ' + imgs.length;
    }
    function closeLb() { lb.remove(); document.body.style.overflow = ''; }

    lb.querySelector('.wk-lightbox__close').addEventListener('click', closeLb);
    lb.addEventListener('click', function(e) { if (e.target === lb) closeLb(); });

    var lbPrev = lb.querySelector('.wk-lightbox__prev');
    var lbNext = lb.querySelector('.wk-lightbox__next');
    if (lbPrev) lbPrev.addEventListener('click', function() { lbGoTo(lbIdx - 1); });
    if (lbNext) lbNext.addEventListener('click', function() { lbGoTo(lbIdx + 1); });

    function lbKey(e) {
      if (e.key === 'Escape') { closeLb(); document.removeEventListener('keydown', lbKey); }
      if (e.key === 'ArrowLeft')  lbGoTo(lbIdx - 1);
      if (e.key === 'ArrowRight') lbGoTo(lbIdx + 1);
    }
    document.addEventListener('keydown', lbKey);

    // Swipe in lightbox
    var lbSx = 0;
    lbTrack.addEventListener('touchstart', function(e) { lbSx = e.touches[0].clientX; }, { passive: true });
    lbTrack.addEventListener('touchend',   function(e) {
      var d = e.changedTouches[0].clientX - lbSx;
      if (Math.abs(d) > 50) d < 0 ? lbGoTo(lbIdx+1) : lbGoTo(lbIdx-1);
    }, { passive: true });
  }

  /* Open lightbox on expand button or on tapping/clicking the photo,
     on ANY device including mobile.
     v1.17: earlier rounds treated the dark backdrop as an accidental
     bug and progressively removed ways to trigger it — which also
     removed the ability to zoom in at all on mobile. The actual fix
     was the backdrop colour (now white, see wk-fixes.css), not the
     trigger. Tapping the photo (or the expand icon) now reliably
     opens the zoomed view on every device again. */
  if (expandBtn) expandBtn.addEventListener('click', function(e) { e.stopPropagation(); openLightbox(cur); });
  mainEl.addEventListener('click', function(e) {
    if (Math.abs(dx) > 8) return;
    if (e.target.closest('.wk-gallery-arrow, .wk-gallery-expand, .wk-gallery-dot')) return;
    openLightbox(cur);
  });

  /* NOTE: no double-tap handler here on purpose — a single tap on
     the photo, or the expand icon, already opens the zoomed view
     above, so a separate double-tap trigger would just be a second
     path to the same thing and isn't needed. */

})();

/* ══════════════════════════════════════════════════════════════
   WHITEKURTI PRO — New Features JS
   ══════════════════════════════════════════════════════════════ */

/* ── Countdown Timer Bar ─────────────────────────────────────────────── */
(function() {
  var bar = document.getElementById('wk-timer-bar');
  var cd  = document.getElementById('wk-timer-countdown');
  var closeBtn = document.getElementById('wk-timer-close');
  if (!bar || !cd) return;

  var mode    = cd.getAttribute('data-mode');
  var endTs   = parseInt(cd.getAttribute('data-end'), 10) * 1000;
  var sessMins = parseInt(cd.getAttribute('data-session-mins'), 10) || 30;

  // Session mode: store end time in sessionStorage
  if (mode === 'session') {
    var storedEnd = sessionStorage.getItem('wk_timer_end');
    if (!storedEnd) {
      var newEnd = Date.now() + sessMins * 60 * 1000;
      sessionStorage.setItem('wk_timer_end', newEnd);
      endTs = newEnd;
    } else {
      endTs = parseInt(storedEnd, 10);
    }
  }

  // FIX v24: removed `window.wkShowToast = showToast;` that used to be here —
  // `showToast` isn't in scope in this IIFE (it's local to a different one),
  // so this threw "ReferenceError: showToast is not defined" and silently
  // killed every script block after it on any page where the timer bar is
  // enabled (mobile menu, search, gallery, add-to-cart, wishlist — all of
  // it). wkShowToast is now exposed once, correctly, right next to the real
  // showToast definition near the top of this file.

  function pad(n) { return n < 10 ? '0' + n : '' + n; }

  function updateTimer() {
    var now  = Date.now();
    var diff = endTs - now;
    if (diff <= 0) {
      bar.classList.add('is-expired');
      if (mode === 'session') sessionStorage.removeItem('wk_timer_end');
      return;
    }
    var h = Math.floor(diff / 3600000);
    var m = Math.floor((diff % 3600000) / 60000);
    var s = Math.floor((diff % 60000) / 1000);
    var elH = document.getElementById('wk-tc-h');
    var elM = document.getElementById('wk-tc-m');
    var elS = document.getElementById('wk-tc-s');
    if (elH) elH.textContent = pad(h);
    if (elM) elM.textContent = pad(m);
    if (elS) elS.textContent = pad(s);
  }

  updateTimer();
  setInterval(updateTimer, 1000);

  if (closeBtn) {
    closeBtn.addEventListener('click', function() {
      bar.style.display = 'none';
      sessionStorage.setItem('wk_timer_closed', '1');
    });
    if (sessionStorage.getItem('wk_timer_closed') === '1') {
      bar.style.display = 'none';
    }
  }
})();

/* ── Social Proof Notifications ─────────────────────────────────────── */
(function() {
  // Run after DOM + scripts fully loaded
  function initSocialProof() {
    var sp = window.wk_social_proof;
    if (!sp) { return; } // data not localized yet
    if (sp.enabled === '0') return;
    var products  = sp.products || [];
    var interval  = parseInt(sp.interval, 10) || 28000;
    if (!products.length) return;

    var popup    = document.getElementById('wk-sp-popup');
    var spName   = document.getElementById('wk-sp-name');
    var spAction = document.getElementById('wk-sp-action');
    var spTime   = document.getElementById('wk-sp-time');
    var spImg    = document.getElementById('wk-sp-img');
    var spClose  = document.getElementById('wk-sp-close');
    if (!popup || !spName) return;

    var firstNames = ['Priya','Ananya','Sneha','Pooja','Neha','Meera','Kavya','Asha','Sonal','Divya','Riya','Nidhi','Swati','Pallavi','Sunita','Geeta','Rekha','Alka','Seema','Shweta','Preeti','Vandana','Sonam','Anjali','Kirti','Rupali','Mansi','Vidya','Lata','Bindu','Shalini','Pratima','Archana','Nisha','Rashmi','Poonam','Yamini','Shilpa','Madhu','Veena','Usha','Sunanda','Kavita','Hema','Beena','Tara','Jyoti','Komal','Shreya','Payal'];
    var cities = ['Mumbai','Delhi','Jaipur','Surat','Pune','Bengaluru','Hyderabad','Chennai','Kolkata','Ahmedabad','Lucknow','Indore','Bhopal','Nagpur','Chandigarh','Kochi','Coimbatore','Vadodara','Agra','Nashik','Udaipur','Jodhpur','Amritsar','Varanasi','Patna','Guwahati','Bhubaneswar','Vijayawada','Mysuru','Rajkot','Dehradun','Jabalpur','Meerut','Faridabad','Allahabad','Raipur','Ludhiana','Madurai','Visakhapatnam','Ranchi'];

    var usedN = [], usedC = [], usedP = [];

    function getNext(arr, used) {
      if (used.length >= arr.length) used.length = 0;
      var avail = arr.filter(function(x,i){ return used.indexOf(i) === -1; });
      if (!avail.length) { used.length = 0; avail = arr.map(function(_,i){ return i; }); }
      var pick = avail[Math.floor(Math.random() * avail.length)];
      used.push(pick);
      return arr[pick];
    }

    var hideTimer = null;

    function showNotification() {
      var name    = getNext(firstNames, usedN);
      var city    = getNext(cities, usedC);
      var product = getNext(products, usedP);
      var ago     = Math.floor(Math.random() * 28) + 2;

      spName.textContent   = name + ' from ' + city;
      spAction.textContent = 'just bought ' + product.name;
      spTime.textContent   = ago + ' minutes ago';

      var imgWrap = document.getElementById('wk-sp-img-wrap');
      if (spImg && product.img) {
        spImg.src = product.img;
        if (imgWrap) imgWrap.style.display = 'block';
      } else {
        if (imgWrap) imgWrap.style.display = 'none';
      }

      popup.style.display = 'block';
      clearTimeout(hideTimer);

      // Force reflow then animate
      void popup.offsetWidth;
      popup.classList.add('is-visible');

      hideTimer = setTimeout(function() {
        popup.classList.remove('is-visible');
        setTimeout(function(){ if (!popup.classList.contains('is-visible')) popup.style.display = ''; }, 500);
      }, 5500);
    }

    if (spClose) {
      spClose.addEventListener('click', function() {
        clearTimeout(hideTimer);
        popup.classList.remove('is-visible');
        setTimeout(function(){ popup.style.display = ''; }, 400);
      });
    }

    // First popup after 7 seconds, then repeat
    setTimeout(function() {
      showNotification();
      setInterval(showNotification, interval);
    }, 7000);
  }

  // Run when DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSocialProof);
  } else {
    initSocialProof();
  }
  })();

/* ── Reviews Load More ───────────────────────────────────────────────── */
(function($) {
  var $btn = $('#wk-reviews-load-more');
  if (!$btn.length) return;

  $btn.on('click', function() {
    if (typeof wk_params === 'undefined') return;
    var page    = parseInt($btn.attr('data-page'), 10) + 1;
    var product = $btn.attr('data-product') || 0;
    $btn.text('Loading...').prop('disabled', true);

    $.post(wk_params.ajax_url, {
      action:     'wk_load_more_reviews',
      product_id: product,
      page:       page,
      nonce:      wk_params.nonce
    }, function(res) {
      if (res.success && res.data.html) {
        $('.wk-reviews-list').append(res.data.html);
        $btn.attr('data-page', page);
        if (!res.data.has_more) {
          $btn.remove();
        } else {
          $btn.html('Read all reviews <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>').prop('disabled', false);
        }
      } else {
        $btn.remove();
      }
    });
  });
}(jQuery));

/* ── Auth Tabs ─────────────────────────────────────────────────── */
(function() {
  var tabs = document.querySelectorAll('.wk-auth-tab');
  tabs.forEach(function(tab) {
    tab.addEventListener('click', function() {
      var targetId = this.getAttribute('data-target');
      var allPanes = document.querySelectorAll('.wk-auth-pane');
      var allTabs  = document.querySelectorAll('.wk-auth-tab');
      allTabs.forEach(function(t) { t.classList.remove('is-active'); });
      allPanes.forEach(function(p) { p.classList.remove('is-active'); });
      this.classList.add('is-active');
      var pane = document.getElementById(targetId);
      if (pane) pane.classList.add('is-active');
    });
  });
})();

/* ── Password Show/Hide Toggle ─────────────────────────────────── */
(function() {
  document.addEventListener('click', function(e) {
    var btn = e.target.closest('.wk-pw-toggle');
    if (!btn) return;
    var targetId = btn.getAttribute('data-target');
    var input    = document.getElementById(targetId);
    if (!input) return;
    var isShowing = input.type === 'text';
    input.type = isShowing ? 'password' : 'text';
    btn.setAttribute('aria-pressed', String(!isShowing));
    var showIcon = btn.querySelector('.wk-eye--open');
    var hideIcon = btn.querySelector('.wk-eye--closed');
    if (showIcon) showIcon.style.display = isShowing ? '' : 'none';
    if (hideIcon) hideIcon.style.display = isShowing ? 'none' : '';
  });
})();

/* ══════════════════════════════════════════════════════════════
   TESTIMONIALS CAROUSEL — now a pure CSS marquee.
   FIX v26: replaced with a seamless auto-scrolling loop; see
   assets/css/wk-fixes.css (.wk-testimonials-track--marquee) and
   assets/js/wk-fixes.js for the hover/touch pause behaviour.
   ══════════════════════════════════════════════════════════════ */

/* ── Fake Purchase Notifications ── */
(function() {
  function init() {
    var cfg = window.wk_fake_notifications;
    if (!cfg || cfg.enabled !== '1') return;

    var popup    = document.getElementById('wk-fn-popup');
    if (!popup) return;

    var elName   = document.getElementById('wk-fn-name');
    var elAction = document.getElementById('wk-fn-action');
    var elTime   = document.getElementById('wk-fn-time');
    var elImg    = document.getElementById('wk-fn-img');
    var elImgWrap= document.getElementById('wk-fn-img-wrap');
    var elClose  = document.getElementById('wk-fn-close');

    var products = cfg.products || [];
    var cities   = cfg.cities   || [];
    var names    = ['Priya','Ananya','Sneha','Pooja','Neha','Meera','Kavya','Asha','Sonal','Divya',
                    'Riya','Nidhi','Swati','Pallavi','Sunita','Geeta','Rekha','Alka','Seema','Shweta',
                    'Preeti','Sonam','Anjali','Kirti','Rupali','Mansi','Vidya','Lata','Shalini','Rashmi',
                    'Poonam','Yamini','Shilpa','Madhu','Komal','Shreya','Payal','Kavita','Hema','Tara'];

    if (!products.length || !cities.length) return;

    /* ── Position the popup ────────────────────────────────────── */
    var pos = cfg.position || 'bottom-left';
    var isMobile = window.innerWidth < 768;

    // Apply base position styles
    popup.style.position   = 'fixed';
    popup.style.zIndex     = '99998';
    popup.style.maxWidth   = isMobile ? 'calc(100vw - 24px)' : '300px';
    popup.style.width      = isMobile ? 'calc(100vw - 24px)' : '300px';
    popup.style.display    = 'none';

    // Clear any previous positioning
    popup.style.top    = '';
    popup.style.bottom = '';
    popup.style.left   = '';
    popup.style.right  = '';
    popup.style.transform = '';

    // On mobile always use bottom-left
    var effectivePos = isMobile ? 'bottom-left' : pos;

    // Apply position
    if (effectivePos === 'bottom-left')   { popup.style.bottom = '80px'; popup.style.left  = '14px'; }
    if (effectivePos === 'bottom-right')  { popup.style.bottom = '80px'; popup.style.right = '14px'; }
    if (effectivePos === 'bottom-center') { popup.style.bottom = '80px'; popup.style.left  = '50%'; popup.style.transform = 'translateX(-50%)'; }
    if (effectivePos === 'top-left')      { popup.style.top    = '80px'; popup.style.left  = '14px'; }
    if (effectivePos === 'top-right')     { popup.style.top    = '80px'; popup.style.right = '14px'; }
    if (effectivePos === 'top-center')    { popup.style.top    = '80px'; popup.style.left  = '50%'; popup.style.transform = 'translateX(-50%)'; }

    // On mobile, position above bottom nav if visible
    var bottomNav = document.getElementById('wk-bottom-nav');
    if (isMobile && bottomNav) {
      popup.style.bottom = (bottomNav.offsetHeight + 12) + 'px';
    }

    /* ── Get product image from current page ────────────────────── */
    function getCurrentPageImage() {
      // On product pages, get the main product image
      var mainImg = document.querySelector('.wk-gallery-img, .woocommerce-product-gallery__image img');
      if (mainImg) return mainImg.src;
      return '';
    }

    /* ── Random helpers ─────────────────────────────────────────── */
    var usedNames = [], usedCities = [], usedProducts = [];
    function pick(arr, used) {
      if (used.length >= arr.length) used.length = 0;
      var avail = [];
      for (var i = 0; i < arr.length; i++) {
        if (used.indexOf(i) === -1) avail.push(i);
      }
      var idx = avail[Math.floor(Math.random() * avail.length)];
      used.push(idx);
      return arr[idx];
    }

    var hideTimer = null;
    var isVisible = false;

    /* ── Show one notification ──────────────────────────────────── */
    function show() {
      if (isVisible) return; // don't stack
      /* Never show when menu, cart, or search overlay is open */
      if (document.body.classList.contains('wk-overlay-open')) return;
      if (document.body.style.overflow === 'hidden') return;

      var name    = pick(names, usedNames);
      var city    = pick(cities, usedCities);
      var product = (cfg.product_specific === '1' && cfg.current_product)
                    ? cfg.current_product
                    : pick(products, usedProducts);
      var minsAgo = Math.floor(Math.random() * 45) + 2;

      if (elName)   elName.textContent   = name + ' from ' + city;
      if (elAction) elAction.textContent = 'just bought ' + product;
      if (elTime)   elTime.textContent   = '● ' + minsAgo + ' min ago';

      // Product image - use current page image if product_specific, else hide
      var imgSrc = '';
      if (cfg.product_specific === '1') {
        imgSrc = getCurrentPageImage();
      }

      // Image / emoji logic for new popup HTML
      var elEmoji = document.getElementById('wk-fn-emoji');
      if (imgSrc && cfg.show_image === '1' && elImg) {
        elImg.src = imgSrc;
        elImg.style.display = 'block';
        if (elEmoji) elEmoji.style.display = 'none';
      } else {
        if (elImg) elImg.style.display = 'none';
        if (elEmoji) elEmoji.style.display = '';
      }

      /* Entrance animation */
      popup.style.display    = 'block';
      popup.style.opacity    = '0';
      popup.style.transition = 'none';

      // Slide direction based on position
      var slideFrom = (effectivePos.indexOf('right') !== -1)
                      ? 'translateX(110%)'
                      : 'translateX(-110%)';
      if (effectivePos.indexOf('center') !== -1) slideFrom = 'translateY(30px)';

      var baseTransform = popup.style.transform || '';
      popup.style.transform = (baseTransform ? baseTransform + ' ' : '') + slideFrom;

      isVisible = true;
      void popup.offsetWidth; // reflow

      popup.style.transition = 'opacity .35s ease, transform .4s cubic-bezier(.34,1.56,.64,1)';
      popup.style.opacity    = '1';
      popup.style.transform  = baseTransform || 'none';

      /* Auto-hide */
      clearTimeout(hideTimer);
      var dur = parseInt(cfg.display_duration, 10) || 5000;
      hideTimer = setTimeout(hide, dur);
    }

    function hide() {
      if (!isVisible) return;
      popup.style.transition = 'opacity .3s ease, transform .3s ease';
      popup.style.opacity    = '0';
      popup.style.transform  = (popup.style.transform || '') + ' translateY(8px)';
      setTimeout(function() {
        popup.style.display = 'none';
        popup.style.transform = popup.style.transform.replace(' translateY(8px)', '');
        isVisible = false;
      }, 320);
    }

    /* Close button */
    if (elClose) {
      elClose.addEventListener('click', function() {
        clearTimeout(hideTimer);
        hide();
      });
    }

    /* Touch swipe to dismiss */
    var swipeStartX = 0;
    popup.addEventListener('touchstart', function(e) {
      swipeStartX = e.touches[0].clientX;
    }, { passive: true });
    popup.addEventListener('touchend', function(e) {
      var diff = e.changedTouches[0].clientX - swipeStartX;
      if (Math.abs(diff) > 50) {
        clearTimeout(hideTimer);
        hide();
      }
    }, { passive: true });

    /* Start loop */
    var firstDelay = parseInt(cfg.first_delay, 10) || 8000;
    var interval   = parseInt(cfg.interval, 10)     || 30000;

    setTimeout(function() {
      show();
      setInterval(show, interval);
    }, firstDelay);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();

/* old zoom code removed — new gallery handles zoom */


/* ── Exit Popup: Mobile Bottom Sheet — swipe-to-dismiss ── */
(function() {
  var popup = document.getElementById('wk-exit-popup');
  if (!popup) return;
  var modal = popup.querySelector('.wk-exit-popup__modal');
  if (!modal) return;
  if (window.innerWidth > 767) return; // desktop only uses original logic

  // Animated close: play slide-out before hiding
  function closeSheet() {
    modal.classList.add('is-closing');
    setTimeout(function() {
      modal.classList.remove('is-closing');
      popup.hidden = true;
      document.body.style.overflow = '';
    }, 280);
  }

  // Override the existing closePopup with animated version
  // by re-binding the close buttons to use closeSheet
  ['wk-ep-close','wk-ep-overlay','wk-ep-dismiss'].forEach(function(id) {
    var el = document.getElementById(id);
    if (!el) return;
    // Clone to strip old listeners
    var clone = el.cloneNode(true);
    el.parentNode.replaceChild(clone, el);
    clone.addEventListener('click', closeSheet);
  });

  // Swipe-to-dismiss: drag sheet down > 80px to dismiss
  var startY = 0, currentY = 0, dragging = false;

  modal.addEventListener('touchstart', function(e) {
    // Only start drag from top 60px of sheet (handle area)
    var touch = e.touches[0];
    var rect  = modal.getBoundingClientRect();
    if (touch.clientY - rect.top > 80) return; // too far down — user is scrolling content
    startY   = touch.clientY;
    currentY = touch.clientY;
    dragging = true;
    modal.style.transition = 'none';
  }, { passive: true });

  modal.addEventListener('touchmove', function(e) {
    if (!dragging) return;
    currentY = e.touches[0].clientY;
    var delta = currentY - startY;
    if (delta < 0) { delta = 0; } // no upward drag
    modal.style.transform = 'translateY(' + delta + 'px)';
  }, { passive: true });

  modal.addEventListener('touchend', function() {
    if (!dragging) return;
    dragging = false;
    modal.style.transition = '';
    var delta = currentY - startY;
    if (delta > 80) {
      // Dragged far enough — close
      modal.style.transform = '';
      closeSheet();
    } else {
      // Snap back
      modal.style.transform = '';
    }
  }, { passive: true });
})();

/* ══════════════════════════════════════════════════════════════
   PRODUCT PAGE — Size Selector, Buy Now, Add to Cart, Variation Price
   ══════════════════════════════════════════════════════════════ */
(function() {
  var variationsWrap = document.getElementById('wk-variations-wrap');
  var wcForm  = document.querySelector('#wk-wc-form .variations_form, .variations_form');
  var notice  = document.getElementById('wk-variation-notice');
  var buyNow  = document.getElementById('wk-buy-now');
  var atcBtn  = document.getElementById('wk-atc-btn');

  // FIX: everything below used to track selections in a separate JS
  // object (`selected`), kept in sync by hand every time a pill was
  // clicked or pre-marked. Any place that missed updating it — or any
  // reason the two could drift apart — let a pill look chosen on screen
  // while the underlying checks still thought nothing had been picked
  // (exactly what kept happening). Reading the *actual* currently
  // `.is-selected` pills straight from the page every time removes that
  // entire class of bug: whatever is visibly selected is, by definition,
  // what gets validated and submitted. There is no second copy of the
  // state left to fall out of sync.
  function getSelectedAttributes() {
    var result = {};
    if (!variationsWrap) return result;
    variationsWrap.querySelectorAll('.wk-var-opt.is-selected').forEach(function(p) {
      if (p.dataset.attr && p.dataset.value) result[p.dataset.attr] = p.dataset.value;
    });
    return result;
  }

  // ── Size/Color pill selection ─────────────────────────────────────────
  if (variationsWrap) {
    var pills = variationsWrap.querySelectorAll('.wk-var-opt');

    // Groups with only one real option get an `is-selected` pill
    // pre-rendered by PHP (see single-product.php) so the shopper isn't
    // forced to click something with no real choice. Sync WooCommerce's
    // hidden select to match on load.
    pills.forEach(function(pill) {
      if (!pill.classList.contains('is-selected')) return;
      var attr  = pill.dataset.attr;
      var value = pill.dataset.value;
      if (!attr || !value) return;
      if (wcForm) {
        var preSelect = wcForm.querySelector('select[name="attribute_' + attr + '"], select[name="' + attr + '"]');
        if (preSelect) {
          preSelect.value = value;
          preSelect.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }
    });

    pills.forEach(function(pill) {
      pill.addEventListener('click', function() {
        if (this.disabled || this.classList.contains('is-disabled')) return; // out of stock
        var attr  = this.dataset.attr;
        var value = this.dataset.value;
        if (!value || !value.trim()) return; // ignore stray/blank options

        // Deselect siblings in same group
        variationsWrap.querySelectorAll('.wk-var-opt[data-attr="' + attr + '"]')
          .forEach(function(p) { p.classList.remove('is-selected'); });

        this.classList.add('is-selected');

        // Update label
        var labelEl = document.getElementById('wk-var-selected-' + attr);
        if (labelEl) labelEl.textContent = ': ' + value;

        // Sync WooCommerce hidden select
        if (wcForm) {
          var wcSelect = wcForm.querySelector('select[name="attribute_' + attr + '"], select[name="' + attr + '"]');
          if (wcSelect) {
            wcSelect.value = value;
            wcSelect.dispatchEvent(new Event('change', { bubbles: true }));
          }
        }
        if (notice) notice.hidden = true;
      });
    });
  }

  // ── Resolve the actual variation ourselves ─────────────────────────────
  // ROOT CAUSE FIX: Buy Now / Add to Cart used to gate purely on the
  // hidden `.variation_id` input that WooCommerce's own bundled
  // variation-form script fills in after it hears a native "change" event
  // on the (hidden) attribute <select> elements. In practice that hand-off
  // is unreliable — timing, script load order, or the field simply never
  // gets touched — so shoppers could select a perfectly valid size,
  // allSelected() would correctly return true, and the button would
  // *still* show "Please select all options" because that unrelated
  // hidden field was still "0". WooCommerce already prints the full
  // variation list as JSON on the form (data-product_variations) for any
  // product with a normal number of variations, so we read that directly
  // and match it against the shopper's actual on-screen selection instead
  // of waiting on WooCommerce's script to do it for us.
  var productVariations = null;
  if (wcForm) {
    try {
      var rawVariations = wcForm.getAttribute('data-product_variations');
      if (rawVariations && rawVariations !== 'false') {
        productVariations = JSON.parse(rawVariations);
      }
    } catch (e) { productVariations = null; }
  }

  function findMatchingVariation() {
    if (!productVariations) return null;
    var current = getSelectedAttributes();
    for (var i = 0; i < productVariations.length; i++) {
      var v = productVariations[i];
      var isMatch = true;
      for (var key in v.attributes) {
        if (!Object.prototype.hasOwnProperty.call(v.attributes, key)) continue;
        var attrName = key.replace(/^attribute_/, '');
        var expected = v.attributes[key]; // empty string means "Any <attr>" is fine
        var have = current[attrName] || '';
        if (expected !== '' && expected.toLowerCase() !== String(have).toLowerCase()) {
          isMatch = false;
          break;
        }
      }
      if (isMatch) return v;
    }
    return null;
  }

  function resolveVariationId() {
    if (!wcForm) return '0';
    var varIdEl = wcForm.querySelector('.variation_id');
    var current = varIdEl ? varIdEl.value : '0';
    if (current && current !== '0') return current;

    var match = findMatchingVariation();
    if (match && match.variation_id) {
      if (varIdEl) varIdEl.value = match.variation_id;
      if (window.jQuery && wcForm) {
        jQuery(wcForm).trigger('found_variation', [match]);
        jQuery(wcForm).trigger('woocommerce_variation_has_changed');
      }
      return String(match.variation_id);
    }
    return '0';
  }

  // ── Check all variants selected ───────────────────────────────────────
  function allSelected() {
    if (!variationsWrap) return true;
    var groups = variationsWrap.querySelectorAll('.wk-variation-group');
    for (var i = 0; i < groups.length; i++) {
      // FIX: a misconfigured/imported product can still end up with a
      // group that has no actual .wk-var-opt buttons inside it (e.g. an
      // attribute whose only values were blank). There's nothing for a
      // shopper to click in that case, so it can't ever be "selected" —
      // skip it instead of blocking Buy Now / Add to Cart forever.
      if (!groups[i].querySelector('.wk-var-opt')) continue;
      // Check the actual on-screen state directly, rather than a
      // separately-tracked copy of it — see getSelectedAttributes() above.
      if (!groups[i].querySelector('.wk-var-opt.is-selected')) return false;
    }
    return true;
  }

  function showNotice() {
    if (notice) { notice.hidden = false; }
    if (variationsWrap) {
      variationsWrap.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      variationsWrap.style.animation = 'none';
      variationsWrap.offsetWidth; // reflow
      variationsWrap.style.animation = 'wkShake .4s ease';
      setTimeout(function() { variationsWrap.style.animation = ''; }, 400);
    }
  }

  // ── WooCommerce variation events (jQuery) ─────────────────────────────
  if (window.jQuery && wcForm) {
    jQuery(wcForm).on('found_variation', function(e, variation) {
      // Price update
      var prEl  = document.querySelector('.wk-pdp__price .wk-price');
      var wasEl = document.querySelector('.wk-pdp__price .wk-price-was');
      var pctEl = document.querySelector('.wk-pdp__price .wk-price-save');

      if (prEl && variation.display_price != null) {
        prEl.textContent = '\u20b9' + Number(Math.round(variation.display_price)).toLocaleString('en-IN');
      }
      if (variation.display_regular_price && variation.display_regular_price > variation.display_price) {
        var disc = Math.round((1 - variation.display_price / variation.display_regular_price) * 100);
        if (wasEl) { wasEl.textContent = '\u20b9' + Number(Math.round(variation.display_regular_price)).toLocaleString('en-IN'); wasEl.style.display = ''; }
        if (pctEl) { pctEl.textContent = '(' + disc + '% OFF)'; pctEl.style.display = ''; }
      } else {
        if (wasEl) wasEl.style.display = 'none';
        if (pctEl) pctEl.style.display = 'none';
      }

      // Stock
      if (buyNow) buyNow.disabled = !variation.is_purchasable || !variation.is_in_stock;
      if (atcBtn) {
        atcBtn.disabled = !variation.is_purchasable || !variation.is_in_stock;
        if (atcBtn.disabled) {
          atcBtn.textContent = 'Out of Stock';
        } else if (atcBtn.textContent.trim() === 'Out of Stock') {
          atcBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 001.99 1.61h9.72a2 2 0 001.99-1.61L23 6H6"/></svg> Add to Cart';
        }
      }
      if (notice) notice.hidden = true;
    });

    jQuery(wcForm).on('reset_data', function() {
      if (buyNow) buyNow.disabled = false;
      if (atcBtn) atcBtn.disabled = false;
    });
  }

  // Build the "attribute_xxx=value" query fragment for whatever the
  // shopper has picked, so the server can resolve the exact variation
  // itself if the client's own best-effort guess (resolveVariationId)
  // didn't land on one. This is what finally makes size selection "just
  // work" — the shopper is never blocked by a client-side lookup failing.
  function selectedAttrsQuery() {
    var qs = '';
    var current = getSelectedAttributes();
    for (var attr in current) {
      if (Object.prototype.hasOwnProperty.call(current, attr)) {
        qs += '&attribute_' + encodeURIComponent(attr) + '=' + encodeURIComponent(current[attr]);
      }
    }
    return qs;
  }

  // ── Size Selection Modal ────────────────────────────────────────────────
  // FIX v1.7: previously, clicking Buy Now / Add to Cart without a size
  // just shook the on-page size group and showed a small notice. The
  // reference flow instead opens a bottom-sheet "Select variant" modal
  // containing only the group(s) still missing a choice; picking one there
  // continues straight into whichever action (Add to Cart or Buy Now) was
  // originally tapped.
  var sizeModal        = document.getElementById('wk-size-modal');
  var sizeModalGroups   = document.getElementById('wk-size-modal-groups');
  var sizeModalContinue = document.getElementById('wk-size-modal-continue');
  var sizeModalClose    = document.getElementById('wk-size-modal-close');
  var sizeModalBackdrop = document.getElementById('wk-size-modal-backdrop');
  var pendingAction     = null; // function to call once all options are selected

  function closeSizeModal() {
    if (!sizeModal) return;
    sizeModal.hidden = true;
    sizeModal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('wk-size-modal-open');
    pendingAction = null;
  }

  function refreshContinueState() {
    if (sizeModalContinue) sizeModalContinue.disabled = !allSelected();
  }

  function openSizeModal(action) {
    // No modal in the markup (simple product) — just run the notice/shake.
    if (!sizeModal || !sizeModalGroups || !variationsWrap) { showNotice(); return; }

    pendingAction = action;
    sizeModalGroups.innerHTML = '';

    var groups = variationsWrap.querySelectorAll('.wk-variation-group');
    for (var i = 0; i < groups.length; i++) {
      var group = groups[i];
      if (!group.querySelector('.wk-var-opt')) continue;
      // Only show groups that still need a choice — matches the reference,
      // which only surfaced Size once Colour was already picked.
      if (group.querySelector('.wk-var-opt.is-selected')) continue;

      var labelText = group.querySelector('.wk-variation-group__label');
      labelText = labelText ? labelText.textContent : '';

      var wrap = document.createElement('div');
      wrap.className = 'wk-size-modal__group';
      var label = document.createElement('span');
      label.className = 'wk-size-modal__group-label';
      label.textContent = labelText;
      wrap.appendChild(label);

      var optsWrap = document.createElement('div');
      optsWrap.className = 'wk-size-modal__group-options';

      var opts = group.querySelectorAll('.wk-var-opt');
      for (var j = 0; j < opts.length; j++) {
        var original = opts[j];
        var clone = original.cloneNode(true);
        clone.classList.remove('is-selected');
        if (original.disabled) { clone.disabled = true; }
        (function(originalBtn, cloneBtn) {
          cloneBtn.addEventListener('click', function() {
            if (cloneBtn.disabled) return;
            // Forward the click to the real pill so all existing
            // selection / WC-sync logic runs exactly as it already does.
            originalBtn.click();
            // Reflect the new state inside the modal itself.
            var siblings = cloneBtn.parentNode.querySelectorAll('.wk-var-opt');
            for (var k = 0; k < siblings.length; k++) siblings[k].classList.remove('is-selected');
            cloneBtn.classList.add('is-selected');
            refreshContinueState();
          });
        })(original, clone);
        optsWrap.appendChild(clone);
      }

      wrap.appendChild(optsWrap);
      sizeModalGroups.appendChild(wrap);
    }

    refreshContinueState();
    sizeModal.hidden = false;
    sizeModal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('wk-size-modal-open');
  }

  if (sizeModalContinue) {
    sizeModalContinue.addEventListener('click', function() {
      if (sizeModalContinue.disabled) return;
      var action = pendingAction;
      closeSizeModal();
      if (typeof action === 'function') action();
    });
  }
  if (sizeModalClose)    sizeModalClose.addEventListener('click', closeSizeModal);
  if (sizeModalBackdrop) sizeModalBackdrop.addEventListener('click', closeSizeModal);

  // ── Buy Now (shared by the desktop button and the mobile sticky bar) ──
  function performBuyNow(btn) {
    var productId   = btn.dataset.productId;
    var productType = btn.dataset.productType;

    if (productType === 'variable' && wcForm) {
      var varId = resolveVariationId(); // best-effort; '0' is OK, server will resolve it
      var params = window.wk_params || {};
      fetch(params.ajax_url || '/wp-admin/admin-ajax.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=wk_add_to_cart&product_id=' + productId +
              '&variation_id=' + (varId || '0') + '&quantity=1' +
              selectedAttrsQuery() + '&nonce=' + (params.nonce || '')
      }).then(function(r) { return r.json(); })
      .then(function(data) {
        if (data && data.success) {
          window.location.href = params.checkout_url || '/checkout';
        } else if (window.wkShowToast) {
          wkShowToast((data && data.data && data.data.message) || 'Could not add to cart.');
        }
      }).catch(function() {
        window.location.href = params.checkout_url || '/checkout';
      });
    } else {
      var p2 = window.wk_params || {};
      window.location.href = (p2.checkout_url || '/checkout') + '?add-to-cart=' + productId;
    }
  }

  if (buyNow) {
    buyNow.addEventListener('click', function() {
      var self = this;
      if (variationsWrap && !allSelected()) { openSizeModal(function() { performBuyNow(self); }); return; }
      performBuyNow(self);
    });
  }

  var stickyBuyNowBtn = document.getElementById('wk-sticky-buy-now-btn');
  if (stickyBuyNowBtn) {
    stickyBuyNowBtn.addEventListener('click', function() {
      var self = this;
      if (variationsWrap && !allSelected()) { openSizeModal(function() { performBuyNow(self); }); return; }
      performBuyNow(self);
    });
  }

  // ── Add to Cart ───────────────────────────────────────────────────────
  // FIX v24: this used to do `wcNativeBtn.click()` on WooCommerce's own
  // hidden button whenever it existed. But WooCommerce puts the
  // `.single_add_to_cart_button` class on EVERY product type's button
  // (simple, variable, grouped) — so that branch always ran, meaning
  // clicking "Add to Cart" submitted the real hidden form and reloaded the
  // whole page instead of adding via AJAX. The AJAX branch below never
  // actually ran for anyone. Now both simple and variable products always
  // go through the same AJAX call.
  function wkAddToCartAjax(btn, quantity) {
    if (variationsWrap && !allSelected()) { openSizeModal(function() { wkAddToCartAjax(btn, quantity); }); return; }

    var productId = btn.dataset.productId;
    var productType = btn.dataset.productType;
    var variationId = 0;
    if (productType === 'variable' && wcForm) {
      variationId = resolveVariationId(); // best-effort; '0' is OK, server will resolve it
    }

    var p3 = window.wk_params || {};
    var originalHTML = btn.innerHTML;
    btn.classList.add('is-loading');
    btn.disabled = true;

    fetch(p3.ajax_url || '/wp-admin/admin-ajax.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'action=wk_add_to_cart&product_id=' + productId +
            '&variation_id=' + (variationId || '0') +
            '&quantity=' + (quantity || 1) +
            selectedAttrsQuery() +
            '&nonce=' + (p3.nonce || '')
    }).then(function(r) { return r.json(); })
    .then(function(data) {
      btn.classList.remove('is-loading');
      btn.disabled = false;
      if (data && data.success) {
        btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> Added!';
        if (window.wkApplyFragments) window.wkApplyFragments(data.data && data.data.fragments);
        if (window.jQuery) {
          jQuery(document.body).trigger('wc_fragment_refresh');
          jQuery(document.body).trigger('added_to_cart', [
            data.data && data.data.fragments, data.data && data.data.cart_hash, btn
          ]);
        }
        setTimeout(function() { btn.innerHTML = originalHTML; }, 2000);
      } else {
        btn.innerHTML = originalHTML;
        var msg = (data && data.data && data.data.message) ? data.data.message : (p3.i18n_error || 'Something went wrong.');
        if (window.wkShowToast) window.wkShowToast(msg); else alert(msg);
      }
    }).catch(function() {
      btn.classList.remove('is-loading');
      btn.disabled = false;
      btn.innerHTML = originalHTML;
      if (window.wkShowToast) window.wkShowToast(p3.i18n_error || 'Something went wrong.');
    });
  }

  if (atcBtn) {
    atcBtn.addEventListener('click', function() { wkAddToCartAjax(atcBtn, 1); });
  }

  var stickyAtcBtn = document.getElementById('wk-sticky-atc-btn');
  if (stickyAtcBtn) {
    stickyAtcBtn.addEventListener('click', function() { wkAddToCartAjax(stickyAtcBtn, 1); });
  }

})();


/* ══════════════════════════════════════════════════════════════
   v1.7 — Share button (PDP gallery overlay)
   Uses the native Web Share sheet where available (mobile browsers),
   falling back to copy-link + toast everywhere else.
   ══════════════════════════════════════════════════════════════ */
(function() {
  'use strict';
  var shareBtn = document.getElementById('wk-share-btn');
  if (!shareBtn) return;

  shareBtn.addEventListener('click', function() {
    var url   = shareBtn.dataset.url || window.location.href;
    var title = shareBtn.dataset.title || document.title;

    if (navigator.share) {
      navigator.share({ title: title, url: url }).catch(function() {});
      return;
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(url).then(function() {
        if (window.wkShowToast) wkShowToast('Link copied to clipboard');
      }).catch(function() {
        if (window.wkShowToast) wkShowToast(url);
      });
    } else if (window.wkShowToast) {
      wkShowToast(url);
    }
  });
})();


/* ══════════════════════════════════════════════════════════════
   v1.10 — Write a Review: star rating, photo picker, AJAX submit
   None of this had any JS behind it before — the stars didn't
   respond to clicks and the photo "+" button didn't do anything.
   ══════════════════════════════════════════════════════════════ */
(function() {
  'use strict';
  var form = document.getElementById('wk-user-review-form');
  if (!form) return;

  // ── Star rating ──────────────────────────────────────────────────────
  var starBtns     = form.querySelectorAll('.wk-review-star-btn');
  var ratingInput  = document.getElementById('wk-user-rating-input');
  var starLabel    = form.querySelector('.wk-review-star-label');
  var labels       = ['', 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent'];

  function setStars(val) {
    starBtns.forEach(function(btn) {
      var v = parseInt(btn.dataset.val, 10);
      btn.classList.toggle('is-filled', v <= val);
      btn.setAttribute('aria-pressed', v <= val ? 'true' : 'false');
    });
    if (starLabel) starLabel.textContent = val > 0 ? labels[val] : '';
  }

  starBtns.forEach(function(btn) {
    btn.addEventListener('click', function() {
      var val = parseInt(btn.dataset.val, 10);
      if (ratingInput) ratingInput.value = val;
      setStars(val);
    });
    btn.addEventListener('mouseenter', function() { setStars(parseInt(btn.dataset.val, 10)); });
  });
  var starRow = form.querySelector('.wk-review-star-row');
  if (starRow) {
    starRow.addEventListener('mouseleave', function() {
      setStars(ratingInput ? parseInt(ratingInput.value, 10) || 0 : 0);
    });
  }

  // ── Photo picker (up to 3, with preview + remove) ──────────────────────
  var photoInput  = document.getElementById('wk-review-photo-input');
  var photoUpload = document.getElementById('wk-review-photo-upload');
  var addLabel    = document.getElementById('wk-review-photo-add-label');
  var selectedFiles = [];
  var MAX_PHOTOS = 3;

  function renderThumbs() {
    photoUpload.querySelectorAll('.wk-review-photo-thumb-wrap').forEach(function(el) { el.remove(); });
    selectedFiles.forEach(function(file, i) {
      var wrap = document.createElement('div');
      wrap.className = 'wk-review-photo-thumb-wrap';
      var img = document.createElement('img');
      img.className = 'wk-review-photo-thumb';
      img.src = URL.createObjectURL(file);
      var rm = document.createElement('button');
      rm.type = 'button';
      rm.className = 'wk-review-photo-remove';
      rm.setAttribute('aria-label', 'Remove photo');
      rm.textContent = '\u00d7';
      rm.addEventListener('click', function() {
        selectedFiles.splice(i, 1);
        renderThumbs();
      });
      wrap.appendChild(img);
      wrap.appendChild(rm);
      photoUpload.insertBefore(wrap, addLabel);
    });
    if (addLabel) addLabel.style.display = selectedFiles.length >= MAX_PHOTOS ? 'none' : '';
  }

  if (photoInput) {
    photoInput.addEventListener('change', function() {
      var files = Array.prototype.slice.call(photoInput.files || []);
      files.forEach(function(f) {
        if (selectedFiles.length >= MAX_PHOTOS) return;
        if (f.type.indexOf('image/') !== 0) return;
        selectedFiles.push(f);
      });
      photoInput.value = ''; // allow re-selecting the same file later
      renderThumbs();
    });
  }

  // ── Submit via AJAX ─────────────────────────────────────────────────
  var msgEl = form.querySelector('.wk-review-form__msg');

  form.addEventListener('submit', function(e) {
    e.preventDefault();
    var params = window.wk_params || {};
    var rating = ratingInput ? parseInt(ratingInput.value, 10) || 0 : 0;

    if (rating < 1) {
      if (msgEl) { msgEl.textContent = 'Please select a rating.'; msgEl.className = 'wk-review-form__msg wk-review-form__msg--error'; msgEl.style.display='block'; }
      return;
    }

    var fd = new FormData();
    fd.append('action', 'wk_submit_user_review');
    fd.append('nonce', params.nonce || '');
    fd.append('wk_product_id', form.querySelector('[name="wk_product_id"]').value);
    fd.append('wk_user_rating', rating);
    fd.append('wk_user_review_text', form.querySelector('[name="wk_user_review_text"]').value);
    selectedFiles.forEach(function(file) { fd.append('wk_review_photos[]', file, file.name); });

    var submitBtn = form.querySelector('.wk-review-form__submit');
    if (submitBtn) submitBtn.disabled = true;
    if (msgEl) { msgEl.textContent = 'Submitting…'; msgEl.className = 'wk-review-form__msg'; msgEl.style.display='block'; }

    fetch(params.ajax_url || '/wp-admin/admin-ajax.php', { method: 'POST', body: fd })
      .then(function(r) { return r.json(); })
      .then(function(data) {
        if (submitBtn) submitBtn.disabled = false;
        if (data && data.success) {
          if (msgEl) { msgEl.textContent = data.data.message || 'Thank you for your review!'; msgEl.className = 'wk-review-form__msg wk-review-form__msg--success'; msgEl.style.display='block'; }
          form.reset();
          setStars(0);
          selectedFiles = [];
          renderThumbs();
        } else {
          if (msgEl) { msgEl.textContent = (data && data.data && data.data.message) || 'Something went wrong. Please try again.'; msgEl.className = 'wk-review-form__msg wk-review-form__msg--error'; msgEl.style.display='block'; }
        }
      })
      .catch(function() {
        if (submitBtn) submitBtn.disabled = false;
        if (msgEl) { msgEl.textContent = 'Network error. Please try again.'; msgEl.className = 'wk-review-form__msg wk-review-form__msg--error'; msgEl.style.display='block'; }
      });
  });
})();


/* ══════════════════════════════════════════════════════════════
   v1.7 — Reviews "Read More" toggle (compact review cards)
   ══════════════════════════════════════════════════════════════ */
(function() {
  'use strict';
  document.addEventListener('click', function(e) {
    var btn = e.target.closest && e.target.closest('.wk-review-readmore');
    if (!btn) return;
    var textEl = btn.closest('.wk-review-card__text');
    if (!textEl) return;

    var expanded = textEl.classList.toggle('is-expanded');
    var full  = textEl.dataset.full  || '';
    var short = textEl.dataset.short || '';

    // Rebuild the text node before the button, preserving the button itself.
    var newText = expanded ? full : short;
    var textNode = document.createTextNode(newText);
    textEl.insertBefore(textNode, btn);
    // Remove any previously-inserted text nodes.
    while (textEl.firstChild !== textNode) textEl.removeChild(textEl.firstChild);
    btn.textContent = expanded ? 'Read Less' : 'Read More';
  });
})();


/* ══════════════════════════════════════════════════════════════
   HERO BANNER v24 — image + text overlay carousel
   FIX v24: replaced the old canvas-particle / mouse-parallax /
   gyroscope-tilt hero with a plain crossfade carousel over real
   photos. Autoplay + arrows + dots + swipe, no decorative overhead.
   ══════════════════════════════════════════════════════════════ */
(function() {
  'use strict';

  var hero  = document.getElementById('wk-herobanner');
  var track = document.getElementById('wk-herobanner-track');
  if (!hero || !track) return;

  var slides   = Array.prototype.slice.call(track.querySelectorAll('.wk-herobanner__slide'));
  var dots     = Array.prototype.slice.call(hero.querySelectorAll('.wk-herobanner__dot'));
  var prevBtn  = document.getElementById('wk-herobanner-prev');
  var nextBtn  = document.getElementById('wk-herobanner-next');
  var total    = slides.length;
  if (total < 2) return; /* single slide — nothing to carousel, just show it */

  var cur      = 0;
  var timer    = null;
  var INTERVAL = 5500;

  function goTo(n) {
    var next = ((n % total) + total) % total;
    slides[cur].classList.remove('is-active');
    slides[cur].setAttribute('aria-hidden', 'true');
    slides[next].classList.add('is-active');
    slides[next].setAttribute('aria-hidden', 'false');
    if (dots[cur]) { dots[cur].classList.remove('is-active'); dots[cur].setAttribute('aria-selected', 'false'); }
    if (dots[next]) { dots[next].classList.add('is-active'); dots[next].setAttribute('aria-selected', 'true'); }
    cur = next;

    /* Lazy-load the incoming slide's image the moment it becomes active */
    var img = slides[cur].querySelector('img[loading="lazy"]');
    if (img) { img.loading = 'eager'; img.fetchPriority = 'high'; }
  }

  function startAuto() {
    clearInterval(timer);
    timer = setInterval(function() { goTo(cur + 1); }, INTERVAL);
  }
  function pauseAuto() { clearInterval(timer); }

  if (prevBtn) prevBtn.addEventListener('click', function() { goTo(cur - 1); startAuto(); });
  if (nextBtn) nextBtn.addEventListener('click', function() { goTo(cur + 1); startAuto(); });
  dots.forEach(function(dot) {
    dot.addEventListener('click', function() {
      goTo(parseInt(dot.dataset.index, 10) || 0);
      startAuto();
    });
  });

  hero.addEventListener('mouseenter', pauseAuto);
  hero.addEventListener('mouseleave', startAuto);
  hero.addEventListener('focusin', pauseAuto);
  hero.addEventListener('focusout', startAuto);

  /* Touch swipe */
  var sx = 0, dx = 0, swiping = false;
  track.addEventListener('touchstart', function(e) {
    sx = e.touches[0].clientX; dx = 0; swiping = true; pauseAuto();
  }, { passive: true });
  track.addEventListener('touchmove', function(e) {
    if (!swiping) return;
    dx = e.touches[0].clientX - sx;
  }, { passive: true });
  track.addEventListener('touchend', function() {
    if (!swiping) return;
    swiping = false;
    if (dx < -40) goTo(cur + 1);
    else if (dx > 40) goTo(cur - 1);
    startAuto();
  }, { passive: true });

  /* Keyboard when hero has focus */
  hero.addEventListener('keydown', function(e) {
    if (e.key === 'ArrowLeft') { goTo(cur - 1); startAuto(); }
    if (e.key === 'ArrowRight') { goTo(cur + 1); startAuto(); }
  });

  startAuto();
})();

/* ══════════════════════════════════════════════════════════
   MOBILE — bottom nav class
 ══════════════════════════════════════════════════════════ */
(function() {
  if (document.querySelector('.wk-bottom-nav')) {
    document.body.classList.add('has-bottom-nav');
  }
})();


/* ══════════════════════════════════════════════════════════════
   QUICK VIEW MODAL
   FIX v24: this was a completely dead feature. The modal HTML, CSS,
   and AJAX endpoint (returns gallery/price/description/stock/ATC
   form) were all fully built in inc/quick-view.php, but:
     1) The trigger button was hooked to woocommerce_after_shop_loop_item,
        which this theme's templates never call — so the button never
        even appeared in the page.
     2) There was no JS anywhere to open the modal, fetch data, or
        populate it, even if the button had existed.
   The button is now rendered directly in wk_product_card() and in the
   PDP "You May Also Like" cards (both already in the PHP templates) —
   this module makes it actually work.
   ══════════════════════════════════════════════════════════════ */
(function() {
  var modal    = document.getElementById('wk-quick-view-modal');
  var overlay  = document.getElementById('wk-qv-overlay');
  var closeBtn = document.getElementById('wk-qv-close');
  var loading  = document.getElementById('wk-qv-loading');
  var content  = document.getElementById('wk-qv-content');
  var galleryEl= document.getElementById('wk-qv-gallery');
  var infoEl   = document.getElementById('wk-qv-info');
  if (!modal || !galleryEl || !infoEl) return;

  var cfg = window.wk_qv_cfg || {};

  function openModal() {
    modal.hidden = false;
    document.body.style.overflow = 'hidden';
  }
  function closeModal() {
    modal.hidden = true;
    document.body.style.overflow = '';
  }
  if (closeBtn) closeBtn.addEventListener('click', closeModal);
  if (overlay) overlay.addEventListener('click', closeModal);
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && !modal.hidden) closeModal();
  });

  function renderGallery(images) {
    if (!images || !images.length) { galleryEl.innerHTML = ''; return; }
    var main = images[0];
    var html = '<img class="wk-qv-main-img" id="wk-qv-main-img" src="' + main.full + '" alt="">';
    if (images.length > 1) {
      html += '<div class="wk-qv-thumbs">';
      images.forEach(function(img, i) {
        html += '<img class="wk-qv-thumb' + (i === 0 ? ' is-active' : '') + '" data-full="' + img.full + '" src="' + img.thumb + '" alt="">';
      });
      html += '</div>';
    }
    galleryEl.innerHTML = html;

    var mainImg = document.getElementById('wk-qv-main-img');
    var thumbs = galleryEl.querySelectorAll('.wk-qv-thumb');
    thumbs.forEach(function(t) {
      t.addEventListener('click', function() {
        mainImg.src = t.dataset.full;
        thumbs.forEach(function(x) { x.classList.remove('is-active'); });
        t.classList.add('is-active');
      });
    });
  }

  function renderInfo(data) {
    var ratingHtml = '';
    if (data.rating_count > 0) {
      ratingHtml = '<div class="wk-qv-rating">' + '★'.repeat(Math.round(data.rating)) + '☆'.repeat(5 - Math.round(data.rating)) +
        ' <span>(' + data.rating_count + ')</span></div>';
    }
    var stockHtml = data.in_stock
      ? ''
      : '<p class="wk-qv-oos" style="color:var(--sale,#b3261e);font-weight:600;font-size:12.5px;margin:0 0 12px;">Out of Stock</p>';

    infoEl.innerHTML =
      (data.cats ? '<p class="wk-qv-cat">' + data.cats + '</p>' : '') +
      '<h2 class="wk-qv-name" id="wk-qv-title">' + data.name + '</h2>' +
      ratingHtml +
      '<div class="wk-qv-price">' + data.price + '</div>' +
      (data.badges || '') +
      (data.short_desc ? '<div class="wk-qv-short-desc">' + data.short_desc + '</div>' : '') +
      stockHtml +
      '<div class="wk-qv-atc-wrap">' + data.atc + '</div>' +
      '<a href="' + data.url + '" class="wk-qv-view-full">View Full Details ' +
      '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>';

    // Wire the embedded native WC add-to-cart form to use the same AJAX
    // endpoint as the rest of the site instead of a full-page form submit.
    var form = infoEl.querySelector('form.cart, .variations_form');
    if (form) {
      // WooCommerce's own variation-matching script (price/stock updates as
      // options are picked) only auto-initializes forms present at page
      // load. This form was just injected via AJAX, so it needs to be
      // re-initialized manually or variation selects won't do anything.
      if (window.jQuery && jQuery.fn.wc_variation_form && jQuery(form).hasClass('variations_form')) {
        jQuery(form).wc_variation_form();
      }
      form.addEventListener('submit', function(e) {
        e.preventDefault();
        var btn = form.querySelector('.single_add_to_cart_button');
        var qtyInput = form.querySelector('input.qty');
        var varIdInput = form.querySelector('.variation_id');
        var variationId = varIdInput ? varIdInput.value : '0';
        if (form.classList.contains('variations_form') && (!variationId || variationId === '0')) {
          if (window.wkShowToast) window.wkShowToast('Please select all options first.');
          return;
        }
        var p = window.wk_params || {};
        var original = btn ? btn.textContent : '';
        if (btn) { btn.disabled = true; btn.textContent = 'Adding…'; }
        fetch(p.ajax_url || '/wp-admin/admin-ajax.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'action=wk_add_to_cart&product_id=' + data.id +
                '&variation_id=' + variationId +
                '&quantity=' + (qtyInput ? qtyInput.value : 1) +
                '&nonce=' + (p.nonce || '')
        }).then(function(r) { return r.json(); })
        .then(function(res) {
          if (btn) { btn.disabled = false; btn.textContent = res && res.success ? 'Added!' : original; }
          if (res && res.success) {
            if (window.wkApplyFragments) window.wkApplyFragments(res.data && res.data.fragments);
            if (window.jQuery) {
              jQuery(document.body).trigger('wc_fragment_refresh');
              jQuery(document.body).trigger('added_to_cart', [res.data.fragments, res.data.cart_hash, btn]);
            }
            setTimeout(closeModal, 900);
          } else if (window.wkShowToast) {
            window.wkShowToast((res && res.data && res.data.message) || 'Could not add to cart.');
          }
        }).catch(function() {
          if (btn) { btn.disabled = false; btn.textContent = original; }
        });
      });
    }
  }

  function loadProduct(productId) {
    if (!cfg.ajax || !cfg.nonce) return;
    openModal();
    loading.style.display = 'flex';
    content.style.display = 'none';

    fetch(cfg.ajax, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'action=wk_quick_view&product_id=' + productId + '&nonce=' + encodeURIComponent(cfg.nonce)
    }).then(function(r) { return r.json(); })
    .then(function(res) {
      loading.style.display = 'none';
      if (res && res.success) {
        renderGallery(res.data.gallery);
        renderInfo(res.data);
        content.style.display = 'block';
      } else {
        infoEl.innerHTML = '<p>' + ((res && res.data && res.data.message) || 'Could not load this product.') + '</p>';
        content.style.display = 'block';
      }
    }).catch(function() {
      loading.style.display = 'none';
      infoEl.innerHTML = '<p>Something went wrong loading this product.</p>';
      content.style.display = 'block';
    });
  }

  document.addEventListener('click', function(e) {
    var btn = e.target.closest('.wk-qv-btn');
    if (!btn) return;
    e.preventDefault();
    var pid = btn.dataset.productId;
    if (pid) loadProduct(pid);
  });
})();
