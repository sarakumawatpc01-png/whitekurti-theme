/* ══════════════════════════════════════════════════════════════
   WhiteKurti — wk-fixes.js (v26)
   Loaded after main.js. Small, targeted behaviours that pair with
   assets/css/wk-fixes.css — kept separate from main.js on purpose
   so future edits here can't get lost in that much larger file.
   ══════════════════════════════════════════════════════════════ */

/* ── Testimonials marquee: pause while a finger is touching it ──
   Hover-to-pause is handled entirely in CSS (:hover). Touch devices
   have no hover state, so without this a visitor trying to read a
   review on their phone would have it scroll out from under them. */
(function () {
  var track = document.getElementById('wk-testimonials-track');
  if (!track || !track.classList.contains('wk-testimonials-track--marquee')) return;

  track.addEventListener('touchstart', function () {
    track.classList.add('is-paused');
  }, { passive: true });

  track.addEventListener('touchend', function () {
    // Small delay so the pause doesn't blip off before the reader
    // has actually lifted their finger and finished reading.
    setTimeout(function () { track.classList.remove('is-paused'); }, 2500);
  }, { passive: true });
})();

/* ══════════════════════════════════════════════════════════════
   v1.11 — Belt-and-braces: force every overlay/drawer/modal closed
   whenever a page is restored from the mobile browser's back-forward
   cache (bfcache). If a visitor opened the cart drawer, menu, search
   panel, or filter drawer, then tapped a product and later tapped
   "back", some mobile browsers restore the previous page exactly as
   it was — including a mid-open dark backdrop — without re-running
   page-load JS. This guarantees a clean, closed state on every
   restore, regardless of which overlay it was.
   ══════════════════════════════════════════════════════════════ */
(function () {
  function closeAllOverlays() {
    document.querySelectorAll('.wk-overlay.is-open').forEach(function (el) {
      el.classList.remove('is-open');
      el.setAttribute('aria-hidden', 'true');
    });
    var filterDrawer = document.getElementById('wk-filter-drawer');
    if (filterDrawer) filterDrawer.classList.remove('is-open');

    // FIX v29: the PDP photo zoom (.wk-lightbox), Quick View / Size
    // Guide (.wk-modal) and the size-selector sheet (.wk-size-modal)
    // are each their own separate overlay system — none of them use
    // the shared .wk-overlay.is-open class this function already
    // handles, so a lightbox/modal left open when the visitor tapped
    // "back" was never being cleaned up here, and a bfcache restore
    // could bring it back still sitting on screen.
    document.querySelectorAll('.wk-lightbox').forEach(function (el) { el.remove(); });
    document.querySelectorAll('.wk-modal:not([hidden])').forEach(function (el) {
      el.setAttribute('hidden', '');
    });
    var sizeModal = document.getElementById('wk-size-modal');
    if (sizeModal) {
      sizeModal.setAttribute('hidden', '');
      sizeModal.setAttribute('aria-hidden', 'true');
    }
    document.body.classList.remove('wk-size-modal-open');

    document.body.classList.remove('wk-overlay-open');
    document.body.style.overflow = '';
  }
  window.addEventListener('pageshow', function (e) {
    if (e.persisted) closeAllOverlays();
  });
})();

/* ── Product page: make sure a variable product's Buy Now / Add to
   Cart buttons stay disabled-looking (but still visible) until all
   options are picked, instead of just silently doing nothing. This
   only adds a class main.js already understands via CSS — it does
   not duplicate any of main.js's own click/AJAX logic. ── */
(function () {
  var wrap = document.getElementById('wk-variations-wrap');
  if (!wrap) return;

  var groups = wrap.querySelectorAll('.wk-variation-group');
  if (!groups.length) return;

  function allSelected() {
    var ok = true;
    groups.forEach(function (g) {
      // A group with no selectable pills at all (e.g. a leftover
      // attribute with only blank values) can never be "chosen" — don't
      // let it hold the buttons in the disabled-looking state forever.
      if (!g.querySelector('.wk-var-opt')) return;
      if (!g.querySelector('.wk-var-opt.is-selected')) ok = false;
    });
    return ok;
  }

  wrap.addEventListener('click', function () {
    var buyNow = document.getElementById('wk-buy-now');
    var atc    = document.getElementById('wk-atc-btn');
    var ready  = allSelected();
    [buyNow, atc].forEach(function (btn) {
      if (btn) btn.classList.toggle('wk-btn--needs-selection', !ready);
    });
  });
})();

/* ══════════════════════════════════════════════════════════════
   v1.14 — Review photos: open the "Real Photos" strip in a
   fullscreen lightbox on click/tap. Previously the thumbnails (and
   the "+N More" tile) were static, non-interactive elements with no
   way to view them at full size.

   This is built with inline styles / DOM APIs rather than reusing
   the shared .wk-lightbox CSS classes, and set to the maximum
   possible z-index. main.css carries more than one z-index "system"
   for overlays (an original 99999x scale, and a later reset pass
   that redefined a different subset of the same class names down to
   a 300–600 range) — depending on which happens to win the cascade
   for a given class, a shared-CSS lightbox can end up sitting UNDER
   another fixed-position element instead of on top of it, which
   looks exactly like a plain dark/black screen where the photo
   should be. Building this one standalone avoids that class of bug
   entirely, and using `img.src =` (not string-concatenated HTML)
   means an unusual character in a photo URL can't ever break the
   markup either.
   ══════════════════════════════════════════════════════════════ */
(function () {
  var strip = document.getElementById('wk-reviews-photostrip');
  if (!strip) return;

  var photos = [];
  try { photos = JSON.parse(strip.getAttribute('data-photos') || '[]'); } catch (e) { photos = []; }
  photos = photos.filter(function (p) { return typeof p === 'string' && p; });
  if (!photos.length) return;

  function openReviewLightbox(startIdx) {
    var idx = Math.max(0, Math.min(startIdx || 0, photos.length - 1));

    var lb = document.createElement('div');
    lb.setAttribute('role', 'dialog');
    lb.setAttribute('aria-modal', 'true');
    lb.setAttribute('aria-label', 'Review photo viewer');
    // v1.17: white background, not black — see main.css .wk-lightbox
    // for the matching product-gallery-zoom fix and why.
    lb.style.cssText = 'position:fixed;inset:0;z-index:2147483647;background:#fff;' +
      'display:flex;align-items:center;justify-content:center;overflow:hidden;';

    var imgEl = document.createElement('img');
    imgEl.alt = 'Review photo';
    imgEl.style.cssText = 'max-width:92vw;max-height:88vh;object-fit:contain;user-select:none;' +
      '-webkit-user-drag:none;border-radius:3px;display:block;box-shadow:0 4px 24px rgba(0,0,0,.15);';
    imgEl.src = photos[idx];
    lb.appendChild(imgEl);

    var closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'wk-rv-lightbox__close';
    closeBtn.setAttribute('aria-label', 'Close');
    closeBtn.innerHTML = '&times;';
    closeBtn.style.cssText = 'position:fixed;top:12px;right:14px;background:rgba(0,0,0,.06);' +
      'border:none;color:#222;font-size:26px;line-height:1;width:42px;height:42px;border-radius:50%;' +
      'cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:2;box-shadow:0 1px 4px rgba(0,0,0,.12);';
    lb.appendChild(closeBtn);

    var counter = null;
    if (photos.length > 1) {
      counter = document.createElement('div');
      counter.style.cssText = 'position:fixed;bottom:18px;left:50%;transform:translateX(-50%);' +
        'color:rgba(0,0,0,.5);font-size:13px;z-index:2;';
      lb.appendChild(counter);

      ['prev', 'next'].forEach(function (dir) {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'wk-rv-lightbox__nav';
        btn.setAttribute('aria-label', dir === 'prev' ? 'Previous photo' : 'Next photo');
        btn.innerHTML = dir === 'prev' ? '&#8249;' : '&#8250;';
        btn.style.cssText = 'position:fixed;top:50%;transform:translateY(-50%);' + (dir === 'prev' ? 'left:10px;' : 'right:10px;') +
          'background:rgba(0,0,0,.06);border:none;color:#222;width:46px;height:46px;border-radius:50%;' +
          'cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:24px;z-index:2;box-shadow:0 1px 4px rgba(0,0,0,.12);';
        btn.addEventListener('click', function (e) { e.stopPropagation(); goTo(idx + (dir === 'prev' ? -1 : 1)); });
        lb.appendChild(btn);
      });
    }

    document.body.appendChild(lb);
    document.body.style.overflow = 'hidden';

    function goTo(n) {
      idx = ((n % photos.length) + photos.length) % photos.length;
      imgEl.src = photos[idx];
      if (counter) counter.textContent = (idx + 1) + ' / ' + photos.length;
    }
    if (counter) counter.textContent = (idx + 1) + ' / ' + photos.length;

    function close() { lb.remove(); document.body.style.overflow = ''; document.removeEventListener('keydown', onKey); }
    function onKey(e) {
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowLeft') goTo(idx - 1);
      if (e.key === 'ArrowRight') goTo(idx + 1);
    }
    document.addEventListener('keydown', onKey);

    closeBtn.addEventListener('click', close);
    lb.addEventListener('click', function (e) { if (e.target === lb) close(); });

    // Swipe support
    var sx = 0;
    lb.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
    lb.addEventListener('touchend', function (e) {
      var d = e.changedTouches[0].clientX - sx;
      if (Math.abs(d) > 50) goTo(idx + (d < 0 ? 1 : -1));
    }, { passive: true });
  }

  strip.addEventListener('click', function (e) {
    var target = e.target.closest('.wk-reviews-photostrip__img, .wk-reviews-photostrip__more');
    if (!target) return;
    openReviewLightbox(parseInt(target.getAttribute('data-index'), 10) || 0);
  });
  strip.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    var target = e.target.closest('.wk-reviews-photostrip__img, .wk-reviews-photostrip__more');
    if (!target) return;
    e.preventDefault();
    openReviewLightbox(parseInt(target.getAttribute('data-index'), 10) || 0);
  });
})();
