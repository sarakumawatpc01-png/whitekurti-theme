<?php
if ( ! defined( 'ABSPATH' ) ) exit; get_header();

// FIX: My Account (and, on some setups, Cart/Checkout) is a normal WP Page
// whose content is just a WooCommerce shortcode. That shortcode already
// prints its OWN "<main id="wk-main" class="wk-woo-main">" wrapper via the
// woocommerce_before_main_content / woocommerce_after_main_content hooks
// (see inc/woocommerce.php). This template used to ALSO wrap the same
// content in its own "<main id="wk-main" class="wk-main wk-container">" +
// "<h1 class="wk-page-title">" block — two nested <main> elements sharing
// one id, and two stacked sets of container padding/margin. That's what
// caused the very large empty gap above "Sign In" and the inconsistent
// side margins on the My Account page. For those pages we now let
// WooCommerce's own wrapper do all the work.
$wk_is_wc_shortcode_page = function_exists( 'is_account_page' ) && ( is_account_page() || is_cart() || is_checkout() );
?>

<?php if ( $wk_is_wc_shortcode_page ) : ?>
	<?php while (have_posts()) : the_post(); the_content(); endwhile; ?>
<?php else : ?>
<main id="wk-main" class="wk-main wk-container">
<?php while (have_posts()) : the_post(); ?>
<article id="post-<?php the_ID(); ?>" <?php post_class('wk-page-content'); ?>>
	<h1 class="wk-page-title"><?php the_title(); ?></h1>
	<div class="wk-page-body"><?php the_content(); ?></div>
</article>
<?php endwhile; ?>
</main>
<?php endif; ?>
<?php get_footer();
